#include "header_files.h"

unordered_map<string, unordered_set<string>> usrToGrpMap;     //usr to grp name

unordered_map<string, fileInformation> grpfnameToFileMap;
unordered_map<string, unordered_set<string>> grpToFnameMap;

unordered_map<string, unordered_set<string>> grpfnameToUserMap; // grpFile => { users }
unordered_map<string, fileInformation>  grpUsrToFdetailsMap;


/* newly added

bool checkifFileExist (string name) {
  struct stat buffer;   
  return (stat (name.c_str(), &buffer) == 0); 
}

ends  */

/*
void uploadAfterDownload(int cSock, string inpt) {
    fileInformation fileInfo;
                        fileInfo.fName = fileName;
                        fileInfo.fPath = fdetails[0].c_str();
                        fileInfo.fSize = fdetails[2];
                        fileInfo.fullHash = fdetails[3];
                        fileInfo.clientSockt = cSock;
                        fileInfo.port = stoi(splitFromDelimiter(fdetails[1], ':').back());
                        fileInfo.Ip = splitFromDelimiter(fdetails[1], ':').front();
                        fileInfo.pieces = fdetails[4].size();
                        for(int i = 5; i < fdetails.size(); i++) {
                            fileInfo.pieceswiseHash.push_back(fdetails[i]);
                        }
                        printInfoSl("request rec: "), printInfo(reply);

                        grpfnameToFileMap[grpfnameKey] = (fileInfo); // remv
                        grpToFnameMap[groupName].insert(fileName); // remv

                        groupDetails[groupName].filenameToDetailsMap[fileName] = fileInfo;
                        groupDetails[groupName].availableFiles.insert(fileName);
                        groupDetails[groupName].activeFiles[fileName][sockToClientDetails[cSock].usernm] = 1;
}
*/


// to print a reply and send it to the client
void printAndSendT(char *reply, int cSock) {
    printf("T-> %s\n", reply); // Log the reply to the console
}

// to handle user logout
void logout(int cSock, vector<string> input) {
    char reply[COMMAND_BUFFER_SIZE];
    bzero(reply, COMMAND_BUFFER_SIZE); // Clear the reply buffer

    // Check for valid input
    if (input.size() != 1) {
        strcpy(reply, "Error: Invalid input arguments, usage: logout");
        printf("T-> %s\n", reply);
        send(cSock, reply, sizeof(reply), 0); // Send error reply to client
        return;
    }
    // Check if user is logged in
    else if (isLoggedIn.find(sockToClientDetails[cSock].usernm) == isLoggedIn.end()) {
        strcpy(reply, "Warning: User Not Logged In");
    } else {
        // User is logged in, proceed to log them out
        isLoggedIn.erase(sockToClientDetails[cSock].usernm);
        bzero(reply, COMMAND_BUFFER_SIZE);
        strcpy(reply, "Success"); // Prepare success message

        //logic for removing from sharable files
    if(usrToGrpMap.find(sockToClientDetails[cSock].usernm) != usrToGrpMap.end())
        for(auto gid : usrToGrpMap[sockToClientDetails[cSock].usernm]) {
            if(groupDetails[gid].usrToFileMap.find(sockToClientDetails[cSock].usernm) != groupDetails[gid].usrToFileMap.end())
                for(auto flname: groupDetails[gid].usrToFileMap[sockToClientDetails[cSock].usernm]) {
                    if(groupDetails[gid].activeFiles.find(flname) != groupDetails[gid].activeFiles.end())  
                        if(groupDetails[gid].activeFiles[flname].find(sockToClientDetails[cSock].usernm) != groupDetails[gid].activeFiles[flname].end())
                            groupDetails[gid].activeFiles[flname][sockToClientDetails[cSock].usernm] = 0;
                }
        }
        // for(auto gid : usrToGrpMap[sockToClientDetails[cSock].usernm]) {
        //     for(auto flname: groupDetails[gid].usrToFileMap[sockToClientDetails[cSock].usernm]) {
        //             groupDetails[gid].activeFiles[flname][sockToClientDetails[cSock].usernm] = 0;
        //     }
        // }
        
        // for(auto it = groupDetails.begin(); it != groupDetails.end(); it++) {
        //    if(groupDetails[it->first].members.find(sockToClientDetails[cSock].usernm) !=  groupDetails[it->first].members.end()) {
        //         groupDetails[it->first].
        //     }
        // }
    }
    printf("T-> %s\n", reply);
    send(cSock, reply, sizeof(reply), 0); // Send reply to client
    return;
}

// to create a new user
void handleCreateUser(int cSock, vector<string> input) {
    char reply[COMMAND_BUFFER_SIZE];
    bzero(reply, COMMAND_BUFFER_SIZE); // Clear the reply buffer

    // Check for valid input
    if (input.size() != 3) {
        strcpy(reply, "Error: Invalid number of inputs, Correct: create_user <username> <password>");
    } else {
        // Check if user already exists
        if (userCreds.find(input[1]) != userCreds.end()) {
            strcpy(reply, "Error: User already exists, Please login!!");
        } else {
            // Creating new user
            userCreds[input[1]] = input[2];
            strcpy(reply, "Successfully created User!!"); // Success message
        }
    }

    printf("T-> %s\n", reply);
    send(cSock, reply, sizeof(reply), 0); // Send reply to client
    return;
}

// to handle user login
void login(int cSock, vector<string> input) {
    char reply[COMMAND_BUFFER_SIZE];
    bzero(reply, COMMAND_BUFFER_SIZE); // Clear the reply buffer

    // Check for valid input
    if (input.size() != 3) {
        strcpy(reply, "Invalid input arguments, usage: login <user_id> <password>");
    } else {
        // Check if user is already logged in
        if (isLoggedIn.find(input[1]) != isLoggedIn.end()) {
            strcpy(reply, "User already Logged In");
        } else if (userCreds.find(input[1]) != userCreds.end()) {
            // Successful login
            strcpy(reply, "Successfully logged in!!");
            printf("T-> %s\n", reply);
            send(cSock, reply, sizeof(reply), 0); // Send success message

            bzero(reply, COMMAND_BUFFER_SIZE); // Clear the reply buffer
            recv(cSock, reply, COMMAND_BUFFER_SIZE, 0); // Get additional info from client
            printf("Client-> %s\n", reply);

            // Create and store client details
            struct clientDetails cd;
            cd.usernm = input[1];
            cd.clientSockt = cSock;
            cd.passwrd = userCreds[input[1]];
            cd.port = stoi(reply); // Get port number
            isLoggedIn[input[1]] = true; // Mark user as logged in

            // if(sockToClientDetails.find(cSock)== sockToClientDetails.end())
                sockToClientDetails[cSock] = cd; // Map socket to client details
            // if(userToClientDetails.find(input[1])== userToClientDetails.end()) {
                userToClientDetails[input[1]] = cd;
                portToClientDetails[cd.port] = cd; // Map port to client details
            // }


            //logic for adding back sharable files
            if(usrToGrpMap.find(sockToClientDetails[cSock].usernm) != usrToGrpMap.end())
                for(auto gid : usrToGrpMap[sockToClientDetails[cSock].usernm]) {
                    if(groupDetails[gid].usrToFileMap.find(sockToClientDetails[cSock].usernm) != groupDetails[gid].usrToFileMap.end())
                        for(auto flname: groupDetails[gid].usrToFileMap[sockToClientDetails[cSock].usernm]) {
                            if(groupDetails[gid].activeFiles.find(flname) != groupDetails[gid].activeFiles.end())  
                                if(groupDetails[gid].activeFiles[flname].find(sockToClientDetails[cSock].usernm) != groupDetails[gid].activeFiles[flname].end())
                                    groupDetails[gid].activeFiles[flname][sockToClientDetails[cSock].usernm] = 1;
                        }
                }
            // for(auto gid : usrToGrpMap[sockToClientDetails[cSock].usernm]) {
            //     for(auto flname: groupDetails[gid].usrToFileMap[sockToClientDetails[cSock].usernm]) {
            //         if(groupDetails[gid].activeFiles.find(flname) != groupDetails[gid].activeFiles.end())  
            //             if(groupDetails[gid].activeFiles[flname].find(sockToClientDetails[cSock].usernm) != groupDetails[gid].activeFiles[flname].end())
            //                 groupDetails[gid].activeFiles[flname][sockToClientDetails[cSock].usernm] = 1;
            //     }
            // }

            return;
        } else {
            strcpy(reply, "This User Not Found please create user first");
        }
    }
    printf("T-> %s\n", reply);
    send(cSock, reply, sizeof(reply), 0); // Send reply to client
}

// to create a group
void handleCreateGroup(int cSock, vector<string> input) {
    char reply[COMMAND_BUFFER_SIZE];
    bzero(reply, COMMAND_BUFFER_SIZE); // Clear the reply buffer

    // Check for valid input
    if (input.size() != 2) {
        strcpy(reply, "Error: Invalid input arguments, usage: create_group <group_id>");
    } else {
        string groupName = input[1];
        // Check if the group already exists
        if (groupDetails.find(groupName) != groupDetails.end()) {
            strcpy(reply, "Error: This Group/Group Id already Exists");
        } else {
            groupData gds; // Create a new group data structure
            gds.admin = sockToClientDetails[cSock].usernm; // Set the admin
            gds.members[sockToClientDetails[cSock].usernm] = sockToClientDetails[cSock]; // Add admin as member
            groupDetails[groupName] = gds; // Store group details

            usrToGrpMap[sockToClientDetails[cSock].usernm].insert(groupName);

            // Create directory for file sharing
            // if (mkdir(&groupName[0], 0777) == -1) {
            //     // Error handling could be added here
            // } else {
            //     printInfoSl("File Sharing Folder/Directory created for group id: "), printInfo(groupName);
            // }
            strcpy(reply, "Success"); // Prepare success message
        }
    }
    printAndSendT(reply, cSock); // Log the reply
    send(cSock, reply, sizeof(reply), 0); // Send reply to client
    return;
}

// to join a group
void handleJoinGroup(int cSock, vector<string> input) {
    char reply[COMMAND_BUFFER_SIZE];
    bzero(reply, COMMAND_BUFFER_SIZE); // Clear the reply buffer

    // Check for valid input
    if (input.size() != 2) {
        strcpy(reply, "Error: Invalid input arguments, join_group <group_id>");
    } else {
        string groupName = input[1];
        // Check if the group exists
        if (groupDetails.find(groupName) == groupDetails.end()) {
            strcpy(reply, "Error: Currently, This Group/ Group Id Does not Exist");
        } else {
            string uname = sockToClientDetails[cSock].usernm; // Get username
            // Check if user is already a member
            if (groupDetails[groupName].members.find(uname) != groupDetails[groupName].members.end()) {
                strcpy(reply, "Warning: User already a group Member");
            } else {
                // Check if user is already in the request list
                if (groupDetails[groupName].pendingReq.find(uname) != groupDetails[groupName].pendingReq.end()) {
                    strcpy(reply, "Warning: User already In Request list");
                } else {
                    groupDetails[groupName].pendingReq[uname] = sockToClientDetails[cSock]; // Add user to pending requests
                    strcpy(reply, "Success added to request list"); // Prepare success message
                }
            }
        }
    }
    printAndSendT(reply, cSock); // Log the reply
    send(cSock, reply, sizeof(reply), 0); // Send reply to client
    return;
}

// to leave a group
void handleLeaveGroup(int cSock, vector<string> input) {
    char reply[COMMAND_BUFFER_SIZE];
    bzero(reply, COMMAND_BUFFER_SIZE); // Clear the reply buffer

    // Check for valid input
    if (input.size() != 2) {
        strcpy(reply, "Error: Invalid input arguments, usage: leave_group <group_id>");
    } else {
        string groupName = input[1];
        // Check if the group exists
        if (groupDetails.find(groupName) == groupDetails.end()) {
            strcpy(reply, "Error: Currently, No Group of this name/id is Present");
        } else {
            string uname = sockToClientDetails[cSock].usernm; // Get username
            // Check if user is a member of the group
            if (groupDetails[groupName].members.find(uname) == groupDetails[groupName].members.end()) {
                strcpy(reply, "Error: User is Not a Group Member");
            } else {
                groupDetails[groupName].members.erase(uname); // Remove user from members
                strcpy(reply, "Success, user left group"); // Prepare success message
                
            //clearing files from this user and user in file list
            string gid = groupName;
            if(groupDetails[groupName].usrToFileMap.find(uname) !=groupDetails[groupName].usrToFileMap.end()) {
                for(auto flname: groupDetails[gid].usrToFileMap[uname]) {
                    if(groupDetails[gid].activeFiles.find(flname) != groupDetails[gid].activeFiles.end())  
                        if(groupDetails[gid].activeFiles[flname].find(uname) != groupDetails[gid].activeFiles[flname].end())
                            groupDetails[gid].activeFiles[flname].erase(uname);
                    if(groupDetails[groupName].fileToUserMap.find(flname) !=  groupDetails[groupName].fileToUserMap.end())        
                        groupDetails[groupName].fileToUserMap[flname].erase(uname);
                    if(groupDetails[groupName].fileToUserMap[flname].size() <=0 ) {
                        groupDetails[groupName].availableFiles.erase(flname);
                    }
                }
                groupDetails[groupName].usrToFileMap.erase(uname);
            }

            


            usrToGrpMap[uname].erase(groupName);
                // usrToGrpMap[uname].erase(groupName);
                // if(groupDetails[groupName].usrToFileMap.find(uname) !=groupDetails[groupName].usrToFileMap.end() )
                // for(auto it : groupDetails[groupName].usrToFileMap[uname] ) {
                //     groupDetails[groupName].availableFiles.erase(it);
                //     groupDetails[groupName].fileToUserMap[it].erase(uname);
                // }
                // groupDetails[groupName].usrToFileMap.erase(uname);

                
                if((groupDetails[groupName].admin == uname)){
                    //change owner if size of group member > 0
                    if(groupDetails[groupName].members.size() > 0) {
                        string usr = (groupDetails[groupName].members.begin())->first;  // Access the key
                                                   //check if any logged in user is there in group?
                        for (auto it = groupDetails[groupName].members.begin();it != groupDetails[groupName].members.end(); ++it) {
                                // Access the key and store it in a string variable
                                // if( isLoggedIn.find(it->first)!= isLoggedIn.end()) {
                                //     usr = it->first;
                                //     break;
                                // }
                                if( isLoggedIn.find(it->first)!= isLoggedIn.end()) {
                                    usr = it->first;
                                    break;
                                }
                        }   
                        cout<< endl;
                        groupDetails[groupName].admin = usr;
                    }
                    else{
                        groupDetails.erase(groupName);
                        // string path = "./" + groupName;
                        // int rv = remove(path);
                        // if (rv)
                        //     printerror(path);       
                        cout<< "delete group" << uname << endl;
                    }
                }
                // groupDetails[groupName].members.erase(uname); // Remove user from members
                // //delete group if size == 0?
                // strcpy(reply, "Success, user left group"); // Prepare success message
            }
        }
    }
    printAndSendT(reply, cSock); // Log the reply
    send(cSock, reply, sizeof(reply), 0); // Send reply to client
    return;
}

// to list all groups
void handleListGroups(int cSock, vector<string> input) {
    char reply[COMMAND_BUFFER_SIZE];
    bzero(reply, COMMAND_BUFFER_SIZE); // Clear the reply buffer

    // Check for valid input
    if (input.size() != 1) {
        strcpy(reply, "Error: Invalid input arguments, usage: list_groups");
    } else {
        strcpy(reply, "Success");
        printAndSendT(reply, cSock); // Log the reply
        send(cSock, reply, sizeof(reply), 0); // Send success reply

        // Prepare list of groups
        string groups = "GROUPS :\n";
        if(groupDetails.size() > 0)
            for (auto e : groupDetails) {
                groups += e.first + "\n"; // Append group names to the list
            }
        else {
            groups += "No Groups\n";
        }
        bzero(reply, COMMAND_BUFFER_SIZE);
        strcpy(reply, &groups[0]); // Copy group list to reply
    }
    printAndSendT(reply, cSock); // Log the reply
    send(cSock, reply, sizeof(reply), 0); // Send reply to client
    return;
}

// to list pending requests for a specific group
void handleListPendingRequests(int cSock, vector<string> input) {
    char reply[COMMAND_BUFFER_SIZE];
    bzero(reply, COMMAND_BUFFER_SIZE); // Clear the reply buffer

    // Check for valid input
    if (input.size() != 2) {
        strcpy(reply, "Error: Invalid input arguments, usage: list_requests <group_id>");
    } else {
        string groupName = input[1];
        // Check if the group exists
        if (groupDetails.find(groupName) == groupDetails.end()) {
            strcpy(reply, "Error: This Group id Doesnt Exist");
        } 
        else if(sockToClientDetails[cSock].usernm != groupDetails[groupName].admin) {
            // cout<< sockToClientDetails[cSock].usernm << " " << groupDetails[groupName].admin << endl;
            strcpy(reply, "Error: You are not owner/admin of group you can't see the request"); // Prepare success message
        }   
        else {
            strcpy(reply, "Success"); // Prepare success message
            string reqs = "List of Pending Users :\n";
            if(groupDetails[groupName].pendingReq.size() <= 0) {
                reqs += "No Pending Requests\n";
            }
            else {
                for (auto e : groupDetails[groupName].pendingReq) {
                 reqs += e.first + "\n"; // Append pending user names to the list
                }
            }
            
            strcpy(reply, &reqs[0]); // Copy pending requests to reply
        }
    }
    printAndSendT(reply, cSock); // Log the reply
    send(cSock, reply, sizeof(reply), 0); // Send reply to client
    return;
}

// to accept a pending request for group membership
void handleAcceptRequest(int cSock, vector<string> input) {
    char reply[COMMAND_BUFFER_SIZE];
    bzero(reply, COMMAND_BUFFER_SIZE); // Clear the reply buffer

    // Check for valid input
    if (input.size() != 3) {
        strcpy(reply, "Error: Invalid input arguments, usage: accept_request <group_id> <user_id>");
    } else {
        string groupName = input[1];
        string uname = input[2];

        // Check if the group exists
        if (groupDetails.find(groupName) == groupDetails.end()) {
            strcpy(reply, "Error: Group with this group id Doesnt Exist");
        } else if (groupDetails[groupName].pendingReq.find(uname) == groupDetails[groupName].pendingReq.end()) {
            strcpy(reply, "Error: No Pending Request at the moment");
        } else if(isLoggedIn.find(sockToClientDetails[cSock].usernm) != isLoggedIn.end() && (groupDetails[groupName].admin == sockToClientDetails[cSock].usernm)){
            groupDetails[groupName].members[uname] = groupDetails[groupName].pendingReq[uname]; // Add user to group members
            groupDetails[groupName].pendingReq.erase(uname); // Remove from pending requests
            strcpy(reply, "Success accepted and added to group"); // Prepare success message
            usrToGrpMap[uname].insert(groupName);
        }
        else {
            strcpy(reply, "Error: seems you are not the admin/owner of group"); // Prepare success message
        }
    }
    printAndSendT(reply, cSock); // Log the reply
    send(cSock, reply, sizeof(reply), 0); // Send reply to client
    return;
}


// check case where diff client has same file check storage for it
//need to update login logout client, only login client could give chunk or file
//need to check for large file.
void handleuploadFile(int cSock,vector<string> input) {
    char replyres[COMMAND_BUFFER_SIZE];
    char reply[METADATA];
    if(input.size()!=3){
        strcpy(reply, "Error: Invalid input arguments, usage: upload_file <filepath> <group Id>");
    }
    else {

        string fileName = splitFromDelimiter(input[1],'/').back();
        string groupName = input[2];
        string filePath = input[1];
        string filePathCheck = filePath;
        if(filePathCheck[0] != '.') {
            if(filePathCheck[0] == '/') {
                filePathCheck = '.' + filePathCheck;
            }
            else filePathCheck = "./" + filePathCheck;
        }

        // string dstFile = groupName+"/"+fileName;
        bzero(replyres,COMMAND_BUFFER_SIZE);
        if(groupDetails.find(groupName)==groupDetails.end()){
            strcpy(replyres,"Error: Invalid Group Name provided");
        } else if(groupDetails[groupName].members.find(sockToClientDetails[cSock].usernm) == groupDetails[groupName].members.end()) {
            strcpy(replyres,"Error: You are not group Member");
        // } else if(!checkifFileExist(fileName, filePathCheck)) {
        //     strcpy(replyres,"Error: Problem with Path of the file");
        } 
        else {
            strcpy(replyres,"Started Uploading ..."); //ready to receive file kind of thing
            printAndSendT(replyres, cSock);
            send(cSock, replyres, COMMAND_BUFFER_SIZE, 0);

            // bzero(replyres,COMMAND_BUFFER_SIZE);
            // recv(cSock , replyres, COMMAND_BUFFER_SIZE);
            
            const size_t METADATA_SIZE = METADATA; //(string(replyres));

            // cout<<" size rec: " <<  METADATA_SIZE<< endl; //test

            // bzero(replyres,COMMAND_BUFFER_SIZE);
            // strcpy(replyres, "Ready to receive File Metadata");
            // send(cSock, replyres, COMMAND_BUFFER_SIZE, 0);

            bzero(reply,METADATA_SIZE);
            recv(cSock , reply, METADATA_SIZE, 0);

            // bzero(reply, COMMAND_BUFFER_SIZE);
            if(string(reply) == "error") {
                bzero(replyres,COMMAND_BUFFER_SIZE);
                strcpy(replyres, "Upload Failed");
            }   
            else {
                vector<string> fdetails = splitFromDelimiter(string(reply), '$');
                //fdetails = [filepath, peer address, file size, file hash, pieces ,piecewise hash]
                string grpfnameKey = groupName + ":" + fileName; 
                // if(grpToFnameMap[groupName].find(fileName) != grpToFnameMap[groupName].end()) {
                if(groupDetails[groupName].availableFiles.find(fileName) != groupDetails[groupName].availableFiles.end()) {
                    
                    // string grpfnameKey = groupName + ":" + fileName; 
                    // bzero(reply,COMMAND_BUFFER_SIZE);

                    
                    bzero(replyres,COMMAND_BUFFER_SIZE);

                    // if(grpfnameToFileMap[grpfnameKey].fullHash == fdetails[3]) {
                    if(groupDetails[groupName].filenameToDetailsMap[fileName].fullHash == fdetails[3]) {
                        
                        
                        // if(grpfnameToUserMap[grpfnameKey].find(sockToClientDetails[cSock].usernm) == grpfnameToUserMap[grpfnameKey].end() ) {
                        if(groupDetails[groupName].fileToUserMap[fileName].find(sockToClientDetails[cSock].usernm) == groupDetails[groupName].fileToUserMap[fileName].end() ) {
                            // logic for checking diff usr/client or same
                            // cout<< groupDetails[groupName].fileToUserMap[fileName] .size() << "  | test |  " << groupDetails[groupName].usrToFileMap[sockToClientDetails[cSock].usernm] .size() << endl;
                            grpfnameToUserMap[grpfnameKey].insert(sockToClientDetails[cSock].usernm); //remv
                            groupDetails[groupName].fileToUserMap[fileName].insert(sockToClientDetails[cSock].usernm);
                            string succ = "file uploaded from client: " + sockToClientDetails[cSock].usernm;
                            succ += " from Port: " + to_string(sockToClientDetails[cSock].port);
                            strcpy(replyres, succ.c_str());
                            groupDetails[groupName].usrToFileMap[sockToClientDetails[cSock].usernm].insert(fileName);
                            // cout<< groupDetails[groupName].fileToUserMap[fileName] .size() << "  | test - 2|  " << groupDetails[groupName].usrToFileMap[sockToClientDetails[cSock].usernm] .size() << endl;
                        }
                        else {
                            strcpy(replyres,"Error: File already uploaded in this group");    
                        }
                    } else {
                        printAndSendT("File content changed, updating the file!", cSock);
                        fileInformation fileInfo;
                        fileInfo.fName = fileName;
                        fileInfo.fPath = fdetails[0].c_str();
                        fileInfo.fSize = fdetails[2];
                        fileInfo.fullHash = fdetails[3];
                        fileInfo.clientSockt = cSock;
                        fileInfo.port = stoi(splitFromDelimiter(fdetails[1], ':').back());
                        fileInfo.Ip = splitFromDelimiter(fdetails[1], ':').front();
                        fileInfo.pieces = fdetails[4].size();
                        for(int i = 5; i < fdetails.size(); i++) {
                            fileInfo.pieceswiseHash.push_back(fdetails[i]);
                        }
                        // printInfoSl("request rec: "), printInfo(reply); //test

                        grpfnameToFileMap[grpfnameKey] = (fileInfo); // remv
                        grpToFnameMap[groupName].insert(fileName); // remv

                        groupDetails[groupName].filenameToDetailsMap[fileName] = fileInfo;
                        groupDetails[groupName].availableFiles.insert(fileName);
                        groupDetails[groupName].activeFiles[fileName][sockToClientDetails[cSock].usernm] = 1;

                        // string grpUsrKey = groupName + ":" + sockToClientDetails[cSock].usernm;
                        // grpUsrToFdetailsMap[grpUsrKey] = fileInfo;
                        grpfnameToUserMap[grpfnameKey].insert(sockToClientDetails[cSock].usernm); //remv
                        groupDetails[groupName].fileToUserMap[fileName].insert(sockToClientDetails[cSock].usernm);
                        groupDetails[groupName].usrToFileMap[fileName].insert(sockToClientDetails[cSock].usernm); 

                        //can also use the groupDetails struct methoh : fileToUserMap()

                        bzero(replyres,COMMAND_BUFFER_SIZE);
                        string succ = "File uploaded from client: " + sockToClientDetails[cSock].usernm;
                        succ += " from Port: " + to_string(sockToClientDetails[cSock].port);
                        strcpy(replyres, succ.c_str());
                        groupDetails[groupName].usrToFileMap[sockToClientDetails[cSock].usernm].insert(fileName);

                    }
                } else {
                    fileInformation fileInfo;
                    fileInfo.fName = fileName;
                    fileInfo.fPath = fdetails[0].c_str();
                    fileInfo.fSize = fdetails[2];
                    fileInfo.fullHash = fdetails[3];
                    fileInfo.clientSockt = cSock;
                    fileInfo.port = stoi(splitFromDelimiter(fdetails[1], ':').back());
                    fileInfo.Ip = splitFromDelimiter(fdetails[1], ':').front();
                    fileInfo.pieces = fdetails[4].size();
                    for(int i = 5; i < fdetails.size(); i++) {
                        fileInfo.pieceswiseHash.push_back(fdetails[i]);
                    }
                    // printInfoSl("request rec: "), printInfo(reply); //test

                    grpfnameToFileMap[grpfnameKey] = (fileInfo); // remv
                    grpToFnameMap[groupName].insert(fileName); // remv

                    groupDetails[groupName].filenameToDetailsMap[fileName] = fileInfo;
                    groupDetails[groupName].availableFiles.insert(fileName);
                    groupDetails[groupName].activeFiles[fileName][sockToClientDetails[cSock].usernm] = 1;

                    // string grpUsrKey = groupName + ":" + sockToClientDetails[cSock].usernm;
                    // grpUsrToFdetailsMap[grpUsrKey] = fileInfo;
                    grpfnameToUserMap[grpfnameKey].insert(sockToClientDetails[cSock].usernm); //remv
                    groupDetails[groupName].fileToUserMap[fileName].insert(sockToClientDetails[cSock].usernm);
                    groupDetails[groupName].usrToFileMap[fileName].insert(sockToClientDetails[cSock].usernm); 

                    //can also use the groupDetails struct methoh : fileToUserMap()

                    bzero(replyres,COMMAND_BUFFER_SIZE);
                    string succ = "200  File uploaded from client: " + sockToClientDetails[cSock].usernm;
                    succ += " from Port: " + to_string(sockToClientDetails[cSock].port);
                    strcpy(replyres, succ.c_str());
                    groupDetails[groupName].usrToFileMap[sockToClientDetails[cSock].usernm].insert(fileName);
                }
            }
        }
    }
    printAndSendT(replyres, cSock);
    send(cSock, replyres, COMMAND_BUFFER_SIZE, 0);
    bzero(reply,METADATA);
}

//download_file <group_id> <file_name> <destination_path>
void handledownloadFile (int cSock,vector<string> input) { 
char reply[COMMAND_BUFFER_SIZE];
bool dontPrint = false;
    if(input.size()!=4) {
        strcpy(reply, "Error: Invalid input arguments, usage: download_file <group Id> <file_name> <destination_path>");
    }
    else {
        
        string fileName = input[2];
        string groupName = input[1];
        string savePath = input[3];
        string savePathCheck = savePath;
        if(savePathCheck[0] != '.') {
            if(savePathCheck[0] == '/') {
                savePathCheck = '.' + savePathCheck;
            }
            else savePathCheck = "./" + savePathCheck;
        }

        string dstFile = groupName+"/"+fileName;
        bzero(reply,COMMAND_BUFFER_SIZE);
        if(groupDetails.find(groupName)==groupDetails.end()){
            strcpy(reply,"Error: Invalid Group Name provided");
        } else if(groupDetails[groupName].members.find(sockToClientDetails[cSock].usernm) == groupDetails[groupName].members.end()) {
            strcpy(reply,"Error: You are not group Member");
        // } else if(!checkifFileExist(fileName, savePathCheck)) {
        //     strcpy(reply,"Error: Problem with Path of the file");
        // } else if(grpfnameToUserMap[(groupName + ":" + fileName)].size() == 0) {
        //         strcpy(reply,"Error: File not found in group");
        } else if(groupDetails[groupName].fileToUserMap[fileName].size() == 0){
                strcpy(reply,"Error: File not found in group");
        }else {
          
            strcpy(reply,"Started Downloading ..."); //ready to receive file kind of thing
            printAndSendT(reply, cSock);
            send(cSock, reply, COMMAND_BUFFER_SIZE, 0);

            bzero(reply,COMMAND_BUFFER_SIZE);
            read(cSock , reply, COMMAND_BUFFER_SIZE);

            // bzero(reply, COMMAND_BUFFER_SIZE);
            if(string(reply) != "requesting peers") {
                bzero(reply,COMMAND_BUFFER_SIZE);
                strcpy(reply, "Download Failed");
            } else {   

                // prepare seeder 
                // string seederInfo = "";
                // for(auto i: grpfnameToUserMap[(groupName + ":" + fileName)]){
                //     if(isLoggedIn[i]){
                //         // seederInfo +=  userToClientDetails[i].port + "$";
                //         seederInfo +=  userToClientDetails[i].usernm + "$";
                //     }
                // }

                string seederInfo = "";
                for(auto i: groupDetails[groupName].fileToUserMap[fileName]){
                    if(isLoggedIn[i] && (userToClientDetails[i].port != sockToClientDetails[cSock].port)){
                        // seederInfo +=  userToClientDetails[i].port + "$";
                        seederInfo +=  userToClientDetails[i].usernm + ":" + to_string(userToClientDetails[i].port) + "$";
                    }
                }
                seederInfo +=  groupDetails[groupName].filenameToDetailsMap[fileName].fSize;
                // seederInfo += grpfnameToFileMap[groupName + ":" + input[2]].fSize;

                bzero(reply,COMMAND_BUFFER_SIZE);
                strcpy(reply, seederInfo.c_str());
                // printAndSendT(reply, cSock);
                printAndSendT("sending user ports", cSock);
                send(cSock, reply, COMMAND_BUFFER_SIZE, 0);
                

                bzero(reply,COMMAND_BUFFER_SIZE);
                read(cSock , reply, COMMAND_BUFFER_SIZE);
                // bzero(reply, COMMAND_BUFFER_SIZE);
                if(string(reply) != "requesting pieces") {
                    bzero(reply,COMMAND_BUFFER_SIZE);
                    strcpy(reply, "Download Failed");
                } else {   
                    string sha1Pieces = "";
                    // for(auto i: grpfnameToFileMap[(groupName + ":" + fileName)].pieceswiseHash){
                    //     sha1Pieces +=  i + "$";
                    // }

                    for(auto i : groupDetails[groupName].filenameToDetailsMap[fileName].pieceswiseHash) {
                        sha1Pieces +=  i + "$";
                    }

                    sha1Pieces = sha1Pieces.substr(0,(sha1Pieces.size()-1));
                    strcpy(reply, sha1Pieces.c_str());

                    printAndSendT("sending pieces info", cSock);
                    dontPrint = true;
                    // send(cSock, reply, COMMAND_BUFFER_SIZE, 0);
                    // //dummy read
                    // read(cSock , reply, COMMAND_BUFFER_SIZE);
                    // send(cSock, seederInfo.c_str(), COMMAND_BUFFER_SIZE, 0);
                    // write(client_socket, &piecewiseHash[fdet[0]][0], piecewiseHash[fdet[0]].length());
                    // seederList[inpt[1]][inpt[2]].insert(client_uid);

                    groupDetails[groupName].fileToUserMap[fileName].insert(sockToClientDetails[cSock].usernm);
                    groupDetails[groupName].usrToFileMap[sockToClientDetails[cSock].usernm].insert(fileName);
                    grpfnameToUserMap[(groupName + ":" + fileName)].insert(sockToClientDetails[cSock].usernm);
                    //semd piecceWise sha1
                    // cout<< "download succesfully processing \n"; //test
                }
            }
            
        }
    }
    if(dontPrint == false)
        printAndSendT(reply, cSock);
    send(cSock, reply, COMMAND_BUFFER_SIZE, 0);

}

void handleStopSharingFiles (int cSock,vector<string> input) { 

    //stop_share <group_id> <file_name>
    char reply[COMMAND_BUFFER_SIZE];
    bzero(reply, COMMAND_BUFFER_SIZE); // Clear the reply buffer
    if(input.size()!=3){
        strcpy(reply, "Error: Invalid input arguments, usage: stop_share <group Id> <file_name>");
    } else {
        string groupName = input[1];
        // Check if the group exists
        if (groupDetails.find(groupName) == groupDetails.end()) {
            strcpy(reply, "Error: This Group id Doesnt Exist");
        } 
        else if(groupDetails[groupName].members.find(sockToClientDetails[cSock].usernm) == groupDetails[groupName].members.end()) {
            strcpy(reply,"Error: You are not group Member");
        } else {
            string gid = input[1];
            string fileToStop = input[2];
            bool stopped = false;
            string uname = sockToClientDetails[cSock].usernm;

            if(groupDetails[groupName].usrToFileMap.find(uname) !=groupDetails[groupName].usrToFileMap.end()) {
                for(auto flname: groupDetails[gid].usrToFileMap[uname]) {
                    if(flname == fileToStop) {
                        if(groupDetails[gid].activeFiles.find(flname) != groupDetails[gid].activeFiles.end())  
                            if(groupDetails[gid].activeFiles[flname].find(uname) != groupDetails[gid].activeFiles[flname].end())
                                groupDetails[gid].activeFiles[flname].erase(uname);
                        if(groupDetails[groupName].fileToUserMap.find(flname) !=  groupDetails[groupName].fileToUserMap.end())        
                            groupDetails[groupName].fileToUserMap[flname].erase(uname);
                            stopped = true;
                    }
                }
                groupDetails[groupName].usrToFileMap[uname].erase(fileToStop);
            }
            if(groupDetails[groupName].fileToUserMap[fileToStop].size() <=0 ) {
                groupDetails[groupName].availableFiles.erase(fileToStop);
            }

            // if(groupDetails[gid].usrToFileMap.find(uname) !=groupDetails[gid].usrToFileMap.end()) {
            //     for(auto flname: groupDetails[gid].usrToFileMap[uname]) {
            //         if(flname == fileToStop) {
            //             if(groupDetails[gid].activeFiles.find(flname) != groupDetails[gid].activeFiles.end())  
            //                 if(groupDetails[gid].activeFiles[flname].find(uname) != groupDetails[gid].activeFiles[flname].end())
            //                     groupDetails[gid].activeFiles[flname].erase(uname);
            //             if( groupDetails[gid].fileToUserMap.find(flname) !=  groupDetails[gid].fileToUserMap.end())        
            //                 groupDetails[gid].fileToUserMap[flname].erase(uname);
            //             stopped = true;
            //         }



            //     }
            //     groupDetails[gid].usrToFileMap[uname].erase(fileToStop);
            //     if(groupDetails[gid].availableFiles.find(fileToStop) != groupDetails[gid].availableFiles.end()) {
            //         if(groupDetails[groupName].activeFiles.find(fileToStop) != groupDetails[groupName].activeFiles.end()) {
            //             int cunt = 0;
            //             for(auto f : groupDetails[groupName].activeFiles[fileToStop]) {
            //                     if(f.second == 1)
            //                         break;
            //                     cunt++;
            //             }
            //             if(cunt == groupDetails[groupName].activeFiles[fileToStop].size()) {
            //                 groupDetails[groupName].availableFiles.erase(fileToStop) ;
            //                 groupDetails[groupName].activeFiles.erase(fileToStop);
            //             }
            //         }

            //     }

            // }

           


            // for(auto flname: groupDetails[gid].usrToFileMap[sockToClientDetails[cSock].usernm]) {
            //         if(flname == fileToStop)  {
            //             groupDetails[gid].activeFiles[flname] = 0;
            //             groupDetails[gid].availableFiles.erase(flname);
            //             groupDetails[gid].fileToUserMap[flname].erase(sockToClientDetails[cSock].usernm);
            //             stopped = true;
            //             break;
            //         }
            //     usrToGrpMap[sockToClientDetails[cSock].usernm].erase(gid);
            //     groupDetails[gid].usrToFileMap.erase(sockToClientDetails[cSock].usernm);
            // }

            if(stopped)
                strcpy(reply, "Success: Stopped sharing");
            else 
                strcpy(reply, "Warning: No such File found in group from your uploads");
        }
    }
    printAndSendT(reply, cSock); // Loggin the reply on tracker console
    send(cSock, reply, sizeof(reply), 0); // to Send reply to client    
}

void handleListFiles (int cSock,vector<string> input) { 
    char reply[COMMAND_BUFFER_SIZE];
    bzero(reply, COMMAND_BUFFER_SIZE); // Clear the reply buffer

    // Check for valid input
    if (input.size() != 2) {
        strcpy(reply, "Error: Invalid input arguments, usage: list_files <group_id>");
    } else {
        string groupName = input[1];
        // Check if the group exists
        if (groupDetails.find(groupName) == groupDetails.end()) {
            strcpy(reply, "Error: This Group id Doesnt Exist");
        } 
        else if(groupDetails[groupName].members.find(sockToClientDetails[cSock].usernm) == groupDetails[groupName].members.end()) {
            strcpy(reply,"Error: You are not group Member");
        }   
        else {
            strcpy(reply, "Success"); // Prepare success message
            string reqs = "List of Sharable Files in Group :\n";
            long reqSize = reqs.size();
            // for (auto e : groupDetails[groupName].availableFiles) {
            //     if(groupDetails[groupName].activeFiles[e])
            //         reqs += e + "\n"; // Append active user file names to the list
            // }
            // vs filesToRemove;
            for (auto e : groupDetails[groupName].availableFiles) { 
                // if(groupDetails[groupName].activeFiles.find(e) != groupDetails[groupName].activeFiles.end()) {
                //     int cunt = 0;
                //     for(auto f : groupDetails[groupName].activeFiles[e]) {
                //             if(f.second == 1)
                //                 break;
                //             cunt++;
                //     }
                //     if(cunt == groupDetails[groupName].activeFiles[e].size()) {
                //         // filesToRemove.push_back(e);
                //         // groupDetails[groupName].activeFiles.erase(e);
                //     }
                //     else {
                //         reqs += e + "\n"; // Append active user file names to the list
                //     }
                // }

                if(groupDetails[groupName].fileToUserMap.find(e) != groupDetails[groupName].fileToUserMap.end()) {
                    for(auto usr : groupDetails[groupName].fileToUserMap[e]) {
                        if (isLoggedIn.find(usr) != isLoggedIn.end()) { 
                            reqs += e + "\n";
                            break;
                        }
                    }

                }
            }

            if(reqs.size() == reqSize) {
                reqs += "No Files to Share\n"; 
            }
            strcpy(reply, &reqs[0]); // Copy pending requests to reply
        }
    }
    printAndSendT(reply, cSock); // Log the reply
    send(cSock, reply, sizeof(reply), 0); // Send reply to client
}

void runCommands(int cSock) {
    char reply[COMMAND_BUFFER_SIZE];
    while (5) {
        bzero(reply, COMMAND_BUFFER_SIZE); // Clear the reply buffer
        recv(cSock, reply, COMMAND_BUFFER_SIZE, 0); // Receive request from client

        // Log the client request
        printf("Client-> %s\n", reply);
        string request(&reply[0]); // Converting reply to string
        vector<string> input = splitFromDelimiter(request, ' '); // Splitting the request into commands

        // Handle various commands
        if (input[0] == "create_user") {
            handleCreateUser(cSock, input);
        } else if (input[0] == "login") {
            login(cSock, input);
        } else if (input[0] == "logout") {
            logout(cSock, input);
        } else if (input[0] == "create_group") {
            handleCreateGroup(cSock, input);
        } else if (input[0] == "join_group") {
            handleJoinGroup(cSock, input);
        } else if (input[0] == "leave_group") {
            handleLeaveGroup(cSock, input);
        } else if (input[0] == "list_groups") {
            handleListGroups(cSock, input);
        } else if (input[0] == "list_requests") {
            handleListPendingRequests(cSock, input);
        } else if (input[0] == "accept_request") {
            handleAcceptRequest(cSock, input);
        }else if (input[0] == "show_downloads") {
            bzero(reply, COMMAND_BUFFER_SIZE);
            strcpy(reply, "showing_downloads");
            printAndSendT(reply, cSock); // Loggin the reply on tracker console
            send(cSock, reply, sizeof(reply), 0); // to Send reply to client
        }else if (input[0] == "stop_share") {
            handleStopSharingFiles(cSock,input);
        }
        else if (input[0] == "download_status") {
           if(input.size() <= 1 || stoi(input[1]) != 1) {
            printAndSendT("Download unsuccessful", cSock);
           }
           else printAndSendT("Download successful", cSock);
        } 
        else if(input[0]=="upload_file"){
            handleuploadFile(cSock,input);
        } else if(input[0]=="download_file"){
            handledownloadFile(cSock,input);
        // }else if(input[0]=="show_downloads"){
        //     showDownloads(client_sock,input);
        }else if(input[0]=="list_files"){
            handleListFiles(cSock,input);
        // }else if(input[0]=="stop_share"){
        //     stopSharing(client_sock,input);
        } else if (input[0] == "quit") {
            // Handle client quit command
            logout(cSock, input);
            bzero(reply, COMMAND_BUFFER_SIZE);
            strcpy(reply, "quit");
            send(cSock, reply, sizeof(reply), 0); // Send quit message to client
            break; // Exit from while loop
        } else {
            // For replying to invalid command
            bzero(reply, COMMAND_BUFFER_SIZE);
            if(input[0] != "handshake")
                strcpy(reply, "Invalid Command");
            else
                strcpy(reply, "handshake");
            printAndSendT(reply, cSock); // Loggin the reply on tracker console
            send(cSock, reply, sizeof(reply), 0); // to Send reply to client
        }
        // if(quit) {
        //     strcpy(reply, "closing connection");
        //     send(cSock, reply, sizeof(reply), 0); 
        //     break;
        // }
    }
}

// to handle client connection commands
void trackerCommandHelper(int cSock) {
    //color
    printColor('Y');
    printf("New thread for client: %d is opened\n", cSock);
    printColor('G');
    printf("Client is now connected to Tracker\n");
    resetColor();
    //reset color

    runCommands(cSock);
    close(cSock); // Closeing the socket connection for thread
    //color
    printColor('B');
    printf("Client: %d is now Disconnected from Tracker\n", cSock);
    resetColor();
    //reset color
}