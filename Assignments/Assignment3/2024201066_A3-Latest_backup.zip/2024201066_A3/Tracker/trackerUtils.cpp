#include "header_files.h"

void printInfo(string info) {
    cout << info <<endl;
}

void printInfoSl(string info) {
    cout << info ;
}

void printerror(string er){
    cerr << er << endl;
}

void printerrorSl(string er){
    cerr << er;
}

// to tokenize asa per delimiter
vector<string> splitFromDelimiter(const string& ipStr, char delimiter) {
    vector<string> result;
    size_t start = 0; // Starting index of the current substring

    // Looping through the entire string
    for (size_t end = 0; end < ipStr.length(); ++end) {
        // When the delimiter is found, extract the substring
        if (ipStr[end] == delimiter) {
            result.push_back(ipStr.substr(start, end - start)); // Extracting from delimiter and add to result
            start = end + 1; // Move the start index to the next character after the delimiter
        }
    }
    // Adding the last substring or if it is the only one
    result.push_back(ipStr.substr(start));

    return result;  
}

void readTrackerInfoFile(const char* filename, vector<string>& data) {
    // Opening the file using the open system call
    int fd = open(filename, O_RDONLY);
    if (fd == -1) {
        cerr << "Failed to open file: " << filename << endl;
        return;
    }

    // Converting here the file descriptor to a FILE* type pointer
    FILE* file = fdopen(fd, "r");
    if (!file) {
        cerr << "Failed to convert the file descriptor to FILE* type" << endl;
        close(fd);
        return;
    }

    char buffer[BUFFER_SIZE];

    // Reading all lines into the vector
    while (fgets(buffer, BUFFER_SIZE, file) != NULL) {
        // Remove newline character if present
        buffer[strcspn(buffer, "\n")] = '\0';
        data.push_back(buffer); // Store each line in the vector
    }
    // Check for errors in reading
    if (ferror(file)) {
        cerr << "Error in reading ip port details from file: " << filename << endl;
    }

    // Closeing the file
    fclose(file);
}

//yet to implement logger for tracker
void processTrackerDetails(int argc, char *argv[]){
    vs trackerData;
    readTrackerInfoFile(argv[1], trackerData);  
    if (trackerData.size() < 2) {
        cerr << "Error: Expected at least 2 lines in the tracker info file." << endl;
        exit(EXIT_FAILURE);
    }

    if(string(argv[2]) == "1"){
        tracker1_ip = trackerData[0];
        tracker1_port = stoi(trackerData[1]);
        curTrackerIP = tracker1_ip;
        curTrackerPort = tracker1_port;
        printColor('Y');
        printf("Tracker 1 Address : %s:%d\n", tracker1_ip.c_str(), tracker1_port);
        resetColor();
    }
    else if (string(argv[2]) == "2") {
        tracker2_ip = trackerData[2];
        tracker2_port = stoi(trackerData[3]);
        curTrackerIP = tracker2_ip;
        curTrackerPort = tracker2_port;
        printf("Tracker 2 Address : %s:%d\n", tracker2_ip.c_str(), tracker2_port);
    }
    else{
        printerror("Error: unable to get details from the tracker info file.");
        exit(EXIT_FAILURE);
    }
}


bool checkifFileExist(string name, const string &path) {
  struct stat status;
  printInfoSl("Test file exist : "), printInfo( to_string(stat (path.c_str(), &status) ));
  return (stat (path.c_str(), &status) == 0);
}

string trimLeadingTrailingSpaces(string& ipStr) {
    size_t startExcludingTabs = ipStr.find_first_not_of(" \t");
    size_t endExcludingTabs = ipStr.find_last_not_of(" \t");

    // If the string is having only spaces, then returning an empty string
    if (startExcludingTabs == string::npos) {
        return "";
    }

    // Returning the final trimmed substring
    return ipStr.substr(startExcludingTabs, endExcludingTabs - startExcludingTabs + 1);
}

void printColor(char colorInitial) {
    switch (colorInitial) {
        case 'G': // Green
            printf("%s", "\033[1m\033[32m");
            break;
        case 'B': // Blue
            printf("%s", "\033[1m\033[34m");
            break;
        case 'C': // Cyan
            printf("%s", "\033[1m\033[36m");
            break;
        case 'x' : // white
            printf("%s", "\033[97m");
            break;
        case 'Y': // Yellow
            printf("%s", "\033[1m\033[33m");
            break;
         // Light Colors
        case 'g': // Light Green
            printf("%s", "\033[1m\033[92m");
            break;
        case 'b': // Light Blue
            printf("%s", "\033[1m\033[94m");
            break;
        case 'c': // Light Cyan
            printf("%s", "\033[1m\033[96m");
            break;
        // Background Colors
        case 'R': //Red             // Background Red
            printf("\033[91m");  // printf("%s", "\033[41m");
            break;
        case 'M': // Background Magenta
            printf("%s", "\033[45m");
            break;
        case 'W': // Background White
            printf("%s", "\033[47m");
            break;
        // Light Background Colors
        case 'k': // Light Background Black (Gray)
            printf("%s", "\033[100m");
            break;
        case 'r': // Light Background Red
            printf("%s", "\033[101m");
            break;
        case 'm': // Light Background Magenta
            printf("%s", "\033[105m");
            break;
        case 'w': // Light Background White
            printf("%s", "\033[107m");
            break;
        default:
            // printf("Invalid color initial.\n");
            return;
    }
}

void resetColor() {
    printf("%s", "\033[0m");
}

void clearLine() {
    printf("\033[2K"); // Clear entire line
}
