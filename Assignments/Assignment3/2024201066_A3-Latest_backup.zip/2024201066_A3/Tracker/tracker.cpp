#include "header_files.h"

string tracker1_ip, tracker2_ip, tracker3_ip, curTrackerIP;
unordered_map<string,clientDetails> userToClientDetails;
unordered_map<string,groupData> groupDetails;
unordered_map<string, string> userCreds;
unordered_map<int,clientDetails> sockToClientDetails;
unordered_map<int,clientDetails> portToClientDetails;
unordered_map<string,bool> isLoggedIn;
uint16_t tracker1_port, tracker2_port, curTrackerPort;
bool quit = false;

void* checkTrackerQuit(void* arg){
    while(true){
        string ipline;
        getline(cin, ipline);

        size_t startExcludingTabs = ipline.find_first_not_of(" \t");
        size_t endExcludingTabs = ipline.find_last_not_of(" \t");

        // If the string is having only spaces, make it an empty string
        if (startExcludingTabs == string::npos) {
            ipline = "";
        }
        // get the trimmed substring
        ipline = ipline.substr(startExcludingTabs, endExcludingTabs - startExcludingTabs + 1);

        if(ipline == "quit"){
            printColor('R');
            printf("closing tracker... \n");
            resetColor();
            // quit = true;
            exit(0);
        }
        else printInfo("Invalid Command, you mean `quit` ?");
    }
}

void startConnection(int tracker_socket, sockaddr_in server_ipPort ) {
    int addrlen = sizeof(server_ipPort);
    vector<thread> threadVector;
    pthread_t  quitHandleThread;
    if(pthread_create(&quitHandleThread, NULL, checkTrackerQuit, NULL) == -1){
        printerror("Erron at pthread execution"); 
        exit(EXIT_FAILURE); 
    }
    while(true){
            int clientSocket = accept(tracker_socket, (SockAdd *)&server_ipPort, (socklen_t *)&addrlen);
            if(clientSocket  < 0){
                printerror("Error while accepting the connection request");
                continue;
            }
            
            printColor('g');
            printInfo("Connection Accepted Successfully");
            resetColor();
            // trackerCommandHelper(client_socket); // for testing
            threadVector.push_back(thread(trackerCommandHelper, clientSocket));
        }

        // for(auto i=threadVector.begin(); i!=threadVector.end(); i++){
        //     if(i->joinable()) i->join();
        // }

     // need to verify clean up    
        for (auto& thread : threadVector) {
            if (thread.joinable()) {
                thread.join();
            }
        }
        close(tracker_socket);
}

int main(int argc, char *argv[]) { 
    if(argc != 3){
        printerror("Input arguments required as <tracker info file name>  <tracker_number> ");
        exit(EXIT_FAILURE);
    }
    //color
    processTrackerDetails(argc, argv);
        printColor('c');
        printInfo("MyTracker is running...");
        resetColor();
        int tracker_socket; 
        struct sockaddr_in server_ipPort; 
    
        if ((tracker_socket = socket(AF_INET, SOCK_STREAM, 0)) == 0) { 
            printerror("socket command failed"); 
            exit(EXIT_FAILURE); 
        } 
        int ArgOption = 1; 
        if (setsockopt(tracker_socket, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &ArgOption, sizeof(ArgOption))) { 
            printerror("setsockopt command failed"); 
            exit(EXIT_FAILURE); 
        } 
        server_ipPort.sin_family = AF_INET; 
        server_ipPort.sin_port = htons(curTrackerPort); 
        if(inet_pton(AF_INET, &curTrackerIP[0], &server_ipPort.sin_addr)<=0)  { 
            printerror("\n This is not a valid address or  address may not be supported"); 
            exit(EXIT_FAILURE); 
        } 
        if (bind(tracker_socket, (SockAdd *)&server_ipPort,  sizeof(server_ipPort))<0) { 
            printerror("bind command failed"); 
            exit(EXIT_FAILURE); 
        } 
        if (listen(tracker_socket, 3) < 0) { 
            printerror("listen command failed"); 
            exit(EXIT_FAILURE); 
        } 
        printColor('b');
        printInfo("Listening....");
        resetColor();
        //reset color
        startConnection(tracker_socket, server_ipPort);
        printColor('B');
        printf("EXITING.\n");
        resetColor();
        return 0; 
} 