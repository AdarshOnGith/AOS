#ifndef SERVER_HEADER 
#define SERVER_HEADER

#include <openssl/sha.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <signal.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <stdarg.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/time.h>
#include <sys/ioctl.h>
#include <netdb.h>
#include <sys/stat.h>
#include <pthread.h>
#include <thread>
#include <fstream>
#include <string>
#include <vector>
#include <unordered_set>
#include <iostream>
#include <mutex>
#include <unordered_map>
#include <map>

using namespace std; 
#define vs vector<string>
#define SockAdd struct sockaddr 
#define BUFFER_SIZE 1024
#define METADATA 524288
#define COMMAND_BUFFER_SIZE 16384
#define APPENDD_DELIMITER '$';

struct clientDetails{
    int port;
    int clientSockt;
    string passwrd;
    string usernm;

};

struct fileInformation{
    int port;
    string Ip;
    int clientSockt;
    string groupId;
    string usernm;
    string fName;
    const char* fPath;
    string fSize;
    string fullHash;
    int pieces;
    vs pieceswiseHash;
};

struct groupData{
    string admin;
    unordered_map<string,clientDetails> members;
    unordered_map<string,clientDetails> pendingReq;

    unordered_map<string,vector<clientDetails>> fileToPorts;

    unordered_set<string> availableFiles;
    unordered_map<string, unordered_map<string, int> > activeFiles;  //when user logout sharable -> 1 not sharabale -> 0
    unordered_map<string, unordered_set<string> > fileToUserMap;
    unordered_map<string, fileInformation> filenameToDetailsMap;

    unordered_map<string, unordered_set<string>> usrToFileMap; //usr to file name
};

extern string logFileName, tracker1_ip, tracker2_ip, curTrackerIP, seederFileName;
extern uint16_t tracker1_port, tracker2_port, curTrackerPort;
extern bool quit;

extern unordered_map<string, string> userCreds;
extern unordered_map<string,bool> isLoggedIn;
extern unordered_map<int,clientDetails> sockToClientDetails;
extern unordered_map<int,clientDetails> portToClientDetails;
extern unordered_map<string,clientDetails> userToClientDetails;
extern unordered_map<string,groupData> groupDetails;


extern unordered_map<string, unordered_set<string>> usrToGrpMap;     //usr to grp name

extern unordered_map<string, fileInformation> grpfnameToFileMap;
extern unordered_map<string, unordered_set<string>> grpToFnameMap;

extern unordered_map<string, unordered_set<string>> grpfnameToUserMap; // grpFile => { users }
extern unordered_map<string, fileInformation>  grpUsrToFdetailsMap;


void readTrackerInfoFile(const char* filename, vector<string>& data);
void processTrackerDetails(int, char **);
void printInfo(string info);
void printerror(string er);
void printInfoSl(string info);
void printerrorSl(string er);
vector<string> splitFromDelimiter(const string& ipStr, char delimiter);
bool checkifFileExist(string name, const string &path) ;
string trimLeadingTrailingSpaces(string& ipStr);
void trackerCommandHelper(int client_socket);

void handleAcceptRequest(int cSock,vector<string> input);
void handleListPendingRequests(int cSock,vector<string> input);
void handleListGroups(int cSock, vector<string> input);
void handleLeaveGroup(int cSock,vector<string> input);
void handleJoinGroup(int cSock,vector<string> input);
void handleCreateGroup(int cSock,vector<string> input);
void login(int cSock,vector<string> input);
void handleCreateUser(int cSock,vector<string> input);
void logout(int cSock,vector<string> input);


void clearLine();
void resetColor();
void printColor(char colorInitial);

#endif