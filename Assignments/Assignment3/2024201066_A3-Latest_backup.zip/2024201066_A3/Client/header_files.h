#ifndef SERVER_HEADER 
#define SERVER_HEADER

#include <openssl/sha.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sstream> 
#include <signal.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <stdarg.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/time.h>
#include <sys/ioctl.h>
#include <netdb.h>
#include <sys/stat.h>
#include <pthread.h>
#include <thread>
#include <fstream>
#include <string>
#include <math.h>
#include <vector>
#include <iostream>
#include <unordered_set>
#include <unordered_map>
#include <map>
#include <mutex>

using namespace std; 
#define vs vector<string>
#define COMMAND_BUFFER_SIZE 16384
#define SockAdd struct sockaddr 
#define PIECE_SIZE 524288
#define BUFFER_SIZE 1024
#define METADATA 524288
#define COMMAND_BUFFER_SIZE 16384
#define APPENDD_DELIMITER '$'
#define O_BINARY 0

struct fileInformation{
    int port;
    string Ip = "127.0.0.1";
    int clientSockt;
    string groupId;
    string usernm;
    string fName;
    const char* fPath; //tp rmv
    string filePath;
    string fSize;
    string fullHash;
    int pieces;
    vs pieceswiseHash;
    vector<int> availabePieces;
};

int checkRead(int rstatus) ;
void printInfo(string info) ;
void printerror(string er);
void printInfoSl(string info);
void printerrorSl(string er);
int isValidInput(string inp0);
string trimLeadingTrailingSpaces(string& ipStr);
void readTrackerInfoFile(const char* filename, vector<string>& data) ;
long long getFileSize(const char *path);
string getFileSha1(const char* path) ;
string getPieceSha1(const char* filepath, string fSize, int chunkNo);
string getContentSha1(const char* content, size_t bytesRead) ;
vector<string> splitFromDelimiter(const string& ipStr, char delimiter) ;
void clientCommandHelper(string input0, char* serverResp, int sock, int myPort, bool &loggedIn) ;

void clearLine();
void resetColor();
void printColor(char colorInitial);

#endif