#include "header_files.h"

#include <condition_variable>
#include <atomic>
#include <queue>

queue<fileInformation*> taskQueue;
mutex queueMutex;
condition_variable cv;
atomic<bool> done(false);



bool loggedIn;

unordered_map <string, vs > fileToPiecesInfo;
unordered_map <string, vs> fileToPeerInfo;
unordered_map <string, fileInformation > uploadedfileToFInfo;
vector<vs> curDownFilePieces;
unordered_map<string, bool> downloads;

string myIP ;
int myPort ;

unordered_map<string, vector<int>> fileChunkInfo;
unordered_map<string, unordered_map<string, bool> >downloadedFiles;
bool isCorruptedFile;

struct reqstdPieceDetails{
    string serverPeerIP;
    string filename;
    int chunkNum;
    string fileSize; 
    string destination;
};


void createFileForWrite(const string& destPath, size_t filesize) {
    
    int fd = open(destPath.c_str(), O_WRONLY | O_CREAT | O_TRUNC | O_BINARY, 0644);
    if (fd == -1) {
        printerror("Error: createFileForWrite Unable to create or open the file.");
        return;
    }
    close(fd);
    printInfo("Success: createFileForWrite created the file for writing.");
}

void transferDataPiece(const char* filepath, int chunkNum, int client_socket) {
    int fd = open(filepath, O_RDONLY);
    if (fd == -1) {
        printerrorSl("Error: Failed to open file for sending data."),printerror(filepath);
        exit(EXIT_FAILURE);
    }

    off_t offset = chunkNum * PIECE_SIZE;
    if (lseek(fd, offset, SEEK_SET) == -1) {
        printerrorSl("Error: Failed to seek in file for sending data."),printerror(filepath);
        close(fd);
        exit(EXIT_FAILURE);
    }

    printInfo("Begin sending data starting from " + to_string(offset)); //test

    char buffer[PIECE_SIZE];
    ssize_t count = read(fd, buffer, sizeof(buffer));
    if (count == -1) {
        printerror("Error: Failed to read file for sending data.");
        close(fd);
        exit(EXIT_FAILURE);
    }

    if (send(client_socket, buffer, count, 0) == -1) {
        printerror("Error: Failed while seeder sending data from file.");
        close(fd);
        exit(EXIT_FAILURE);
    }

    printInfo("currently sent data upto: " + to_string(offset + count)); // + string(buffer)); //test
    close(fd);
}

void writeDownloadedPieceToFile(int sock, int pieceNum, char* filePath, string fileName, string fileSize) {  
    int n, tot = 0;
    char buffer[PIECE_SIZE];
    string content = "";

    int fd = open(filePath, O_RDWR | O_BINARY);
    if (fd == -1) {
        printerrorSl("Error: Failed to open file for writing into it."),printerror(filePath);
        return;
    }

    while (tot < PIECE_SIZE) {
        n = read(sock, buffer, sizeof(buffer));
        if (n <= 0) {
            break;
        }
        buffer[n] = 0;

        lseek(fd, pieceNum * PIECE_SIZE + tot, SEEK_SET);
        write(fd, buffer, n);

        printInfo("Data Piece is written at: " + to_string(pieceNum * PIECE_SIZE + tot)); //test
        // printInfoSl("Writted Data: "), printInfo(buffer); //test
        printInfo("Data Piece is written upto:  | " + fileSize + "  | " + to_string(pieceNum * PIECE_SIZE + tot + n - 1) + "\n"); //test
        
        
        content += buffer;
        tot += n;
        bzero(buffer, PIECE_SIZE);
    }

    close(fd);

    string hash = "";
    // hash += getContentSha1(content.c_str(),  n);
    hash += getPieceSha1(filePath, fileSize ,pieceNum);

    //printInfo("written hash: " + hash + "\n"); //test
    //printInfo("original hash: " + (fileToPiecesInfo[fileName][pieceNum]) + "\n"); //test
        
    if (hash != fileToPiecesInfo[fileName][pieceNum]) {
        isCorruptedFile = true;
        printerror("Error: File data corruption detected! ");
    }
    return;
}

string startCommunication (int pSock, const char* serverPeerIP,  size_t peerPort, string command) {

     printInfo("Connected to peer node: " + string(serverPeerIP) + ":" + to_string(peerPort));
 
        string cmdToRun = splitFromDelimiter(command, '$').front();
        printInfoSl("requested command: "), printInfo(cmdToRun);


    /* from here can be moved out of it*/
        if(cmdToRun == "send_pieces_Info"){
            if(send(pSock , &command[0] , strlen(&command[0]) , MSG_NOSIGNAL ) == -1){
                printerrorSl("Error: "),printerror(strerror(errno));
                return "error"; 
            }

            printInfoSl("sent command to peer: "), printInfo(command);

            char leacherreply[COMMAND_BUFFER_SIZE];
            bzero(leacherreply,COMMAND_BUFFER_SIZE);
            
            if(recv(pSock, leacherreply, COMMAND_BUFFER_SIZE, 0) < 0){
                printerror("Error: Failed to read peer response");
                return "error";
            }

            printInfo("got reply from peer: " + string(leacherreply));

            close(pSock);
            return string(leacherreply);
        }
        else if(cmdToRun == "getDataPiece"){
            //command format: "getDataPiece $$ filename $$ to_string(chunkNum) $$ destination
            if(send(pSock , &command[0] , strlen(&command[0]) , MSG_NOSIGNAL ) == -1){
                printerrorSl("Error: "),printerror(strerror(errno));
                return "error"; 
            }
            printInfo("sent command to peer: " + command);

            vs cmdtokens = splitFromDelimiter(command, '$');
            
            string despath = cmdtokens[3];
            int chunkNum = stoi(cmdtokens[2]);
            string filesz = cmdtokens[4];

            printInfo("\ngetting chunk " + to_string(chunkNum) + " from "+ to_string(peerPort));
            writeDownloadedPieceToFile(pSock, chunkNum, &despath[0], cmdtokens[1], filesz);

            return "success"; //200
        }
        else if(cmdToRun == "get_file_path"){
            if(send(pSock , &command[0] , strlen(&command[0]) , MSG_NOSIGNAL ) == -1){
                printerrorSl("Error: "),printerror(strerror(errno));
                return "error"; 
            }
            char leacherreply[COMMAND_BUFFER_SIZE] = {0};
            if(recv(pSock, leacherreply, COMMAND_BUFFER_SIZE,0) < 0){
                printerror("Error: Failed to read peer response");
                return "error";
            }
            printInfo("server reply for get file path:" + string(leacherreply));
            // fileToFilePath[splitString(command, '$').back()] = string(leacherreply);
        }

}


string peerToPeerConnect(const char* serverPeerIP, size_t peerPort, string command){
    struct sockaddr_in peer_serv_addr; 
    int pSock = 0;

    // printInfo("\nInside PeerToPeerConnect fn"); //testing

    if ((pSock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {  
        printInfo("Error: Socket creation error \n"); 
        return "error"; 
    } 
    printInfo("Socket Created for Downloading file");

    peer_serv_addr.sin_family = AF_INET; 
    // uint16_t peerPort = serverPortIP; //stoi(string(serverPortIP));
    peer_serv_addr.sin_port = htons(peerPort); 
    
    
    printInfo("\nNow attempting to connect to " + string(serverPeerIP) + ":" + to_string(peerPort));

    if(inet_pton(AF_INET, serverPeerIP, &peer_serv_addr.sin_addr) < 0){ 
        printerror("Error: This is not a valid address or  address may not be supported"); 
    } 
    if (connect(pSock, (struct sockaddr *)&peer_serv_addr, sizeof(peer_serv_addr)) < 0) { 
        printerrorSl("Error: Failed to connect to Peer"), printerror(strerror(errno));
        //add retry logic
    }
    else{ 
       startCommunication(pSock, serverPeerIP, peerPort, command);
    }
/* till here can be moved out of it*/
    close(pSock);
    printInfo("Now ending connection with " + string(serverPeerIP) + ":" + to_string(peerPort));
    return "success"; //200
}

int getfilePiece(reqstdPieceDetails* reqstdPiece){

    printInfo("Data Chunk fetching details :" + reqstdPiece->filename + " " + 
            reqstdPiece->serverPeerIP + " " + to_string(reqstdPiece->chunkNum));

    string filename = reqstdPiece->filename;
    // printInfo("filename : done \n "); //test
    vs peerServerPeerIP = splitFromDelimiter(reqstdPiece->serverPeerIP, ':');
    long long chunkNum = reqstdPiece->chunkNum;

    string destination = reqstdPiece->destination; 
    //seg flt
    string command = "getDataPiece$" + filename + "$" + to_string(chunkNum) + "$" + destination + "$" + reqstdPiece->fileSize;
    // peerToPeerConnect(&serverPeerIP[0][0], stoi(serverPeerIP[1]), command);
    // printInfo("going for connect : done \n "); //test
    if(peerToPeerConnect(&peerServerPeerIP[0][0], stoi(peerServerPeerIP[1]), command) == "error")
            return -1;
    
    delete reqstdPiece;
    return 1;
}

void getPieceInfoFromPeers(fileInformation* fiPtr){
    printColor('Y');
    printInfoSl("Fetching piece info of : "), printInfoSl(fiPtr->fName), printInfoSl(" from "),  printInfo(fiPtr->Ip + ":" + to_string(fiPtr->port) );
    resetColor();
    
    string serverPeerIp = fiPtr->Ip;
    size_t serverPeerPort = fiPtr->port;
    
    string command = "send_pieces_Info$" + string(fiPtr->fName);
    string response = peerToPeerConnect(serverPeerIp.c_str(), serverPeerPort, command);
    // cout<< " rasd ps: " << response << endl;
    for(size_t i=0; i<curDownFilePieces.size(); i++){
        if(response != "error" && response.size() != 0 ) {//response[i] == '1'){
            curDownFilePieces[i].push_back(string(fiPtr->Ip + ":" + to_string(serverPeerPort) ));
        }
    }
    delete fiPtr;
}

void worker() {
    while (true) {
        fileInformation* fiptr = nullptr;

        {
            unique_lock<mutex> lock(queueMutex);
            cv.wait(lock, [] { return !taskQueue.empty() || done; });

            if (done && taskQueue.empty()) {
                return; // Exit if done and queue is empty
            }

            fiptr = taskQueue.front();
            taskQueue.pop();
        }

        getPieceInfoFromPeers(fiptr);
    }
}
//replaced (original below this)
int preComputeForDownload(vs inpt, int sock, string myIp, int myPort, vs peersWithFile, vs sha1Pieces, string fileSizeStr) {
    // inpt = [command, group id, filename, destination]

    size_t pieces = ceil((stoll(fileSizeStr)) / (float)(PIECE_SIZE));

    curDownFilePieces.clear();
    curDownFilePieces.resize(pieces);
    printInfo("Precomputing Pieces and choosing seeders for Pieces");

    // Thread pool to get piece info from peers
    vector<thread> threads;
    for (size_t i = 0; i < 2; ++i) {
        threads.emplace_back(worker);
    }

    for (size_t i = 0; i < peersWithFile.size(); ++i) {
        fileInformation* fiptr = new fileInformation();
        vector<string> temp = splitFromDelimiter(peersWithFile[i], ':');

        fiptr->fName = inpt[2];
        fiptr->usernm = temp[0];
        fiptr->port = stoi(temp[1]);
        fiptr->fSize = fileSizeStr;
        fiptr->pieces = pieces;

        {
            lock_guard<mutex> lock(queueMutex);
            taskQueue.push(fiptr);
        }
        cv.notify_one();
    }

    {
        lock_guard<mutex> lock(queueMutex);
        done = true;
    }
    cv.notify_all();

    for (auto& th : threads) {
        th.join();
    }

    printInfo("gathered information needed for file downloading...");

    // Verify all chunks are available
    for (size_t i = 0; i < curDownFilePieces.size(); i++) {
        if (curDownFilePieces[i].size() == 0) {
            printerror("Error: Could not find all the parts of the file available to download.");
            return -1;
        }
    }

    // Create destination directory if it doesn't exist
    struct stat info;
    if (stat(inpt[3].c_str(), &info) != 0) {
        mkdir(inpt[3].c_str(), 0755);
    }

    string destPath = inpt[3] + "/" + inpt[2];
    FILE* fd = fopen(&destPath[0], "r+");
    if (fd != 0) {
        printInfo("The file already exists.");
        fclose(fd);
        downloadedFiles[inpt[1]][inpt[2]] = true;
        return 1;
    } else {
        printInfo("The file already does not exists. creating it");
    }

    createFileForWrite(destPath, stoll(fileSizeStr));

    fileChunkInfo[inpt[2]].resize(pieces, 0);
    vector<int> tmp(pieces, 0);
    isCorruptedFile = false;
    fileChunkInfo[inpt[2]] = tmp;

    srand((unsigned)time(0)); // initialize random seed

    // Thread pool for downloading pieces
    const int numDownloadThreads = 4;
    std::queue<reqstdPieceDetails*> downloadTaskQueue;
    std::mutex downloadQueueMutex;
    std::condition_variable downloadCv;
    bool downloadDone = false;
    std::atomic<long long> pieceReceivedAtomic{0};

    // Worker lambda to download pieces from the queue
    auto downloadWorker = [&]() {
        while (true) {
            reqstdPieceDetails* task = nullptr;
            {
                std::unique_lock<std::mutex> lock(downloadQueueMutex);
                downloadCv.wait(lock, [&] { return !downloadTaskQueue.empty() || downloadDone; });
                if (downloadDone && downloadTaskQueue.empty()) return;
                task = downloadTaskQueue.front();
                downloadTaskQueue.pop();
            }

            if (getfilePiece(task) != -1) {
                pieceReceivedAtomic++;
            } else {
                // Reset piece state for retry if needed
                fileChunkInfo[task->filename][task->chunkNum] = 0;
            }
            // delete task;
        }
    };

    // Launch download worker threads
    vector<thread> downloadThreads;
    for (int i = 0; i < numDownloadThreads; ++i) {
        downloadThreads.emplace_back(downloadWorker);
    }

    downloadedFiles[inpt[1]][inpt[2]] = false;

    // Main loop: enqueue tasks for pieces not yet downloaded
    while (pieceReceivedAtomic < (long long)pieces) {
        int randomPiece;
        {
            std::lock_guard<std::mutex> lock(downloadQueueMutex);
            do {
                randomPiece = rand() % pieces;
            } while (fileChunkInfo[inpt[2]][randomPiece] != 0);

            long long peersWithThisPiece = curDownFilePieces[randomPiece].size();
            string randompeer = curDownFilePieces[randomPiece][rand() % peersWithThisPiece];

            reqstdPieceDetails* reqMeta = new reqstdPieceDetails();
            reqMeta->filename = inpt[2];
            reqMeta->serverPeerIP = randompeer;
            reqMeta->chunkNum = randomPiece;
            reqMeta->destination = destPath;
            reqMeta->fileSize = fileSizeStr;

            printInfo("Initiating thread for Piece number " + to_string(reqMeta->chunkNum));
            fileChunkInfo[inpt[2]][randomPiece] = 1;

            downloadTaskQueue.push(reqMeta);
        }
        downloadCv.notify_one();

        std::this_thread::sleep_for(std::chrono::milliseconds(10)); // avoid busy waiting
    }

    // Signal threads to finish and join
    {
        std::lock_guard<std::mutex> lock(downloadQueueMutex);
        downloadDone = true;
    }
    downloadCv.notify_all();

    for (auto& th : downloadThreads) {
        if (th.joinable()) th.join();
    }

    // Finalize status after download
    if (isCorruptedFile) {
        printColor('R');
        printInfo("Error: Download completed but file maybe corrupted.");
        resetColor();
        downloadedFiles[inpt[1]].erase(inpt[2]);
    } else {
        printColor('G');
        printInfo("Download completed Successfully.");
        resetColor();
        downloadedFiles[inpt[1]][inpt[2]] = true;

        fileInformation fileInfo;
        fileInfo.fName = inpt[2];
        fileInfo.fPath = destPath.c_str();
        fileInfo.filePath = destPath;
        fileInfo.fSize = fileSizeStr;
        fileInfo.pieceswiseHash = sha1Pieces;
        fileInfo.clientSockt = sock;
        fileInfo.port = myPort;
        fileInfo.Ip = myIp;
        fileInfo.pieces = pieces;
        uploadedfileToFInfo[inpt[2]] = fileInfo;

        return 1;
    }

    return -1;
}


//original
// int preComputeForDownload (original name)
int preComputeForDownloadOriginal(vs inpt, int sock, string myIp, int myPort, vs peersWithFile, vs sha1Pieces, string fileSizeStr) {
    // inpt = [command, group id, filename, destination]

    size_t pieces= ceil( (stoll(fileSizeStr))/(float)(PIECE_SIZE) );
    // cout<< "num of pieces: " << pieces <<endl; //test

    curDownFilePieces.clear();
    curDownFilePieces.resize(pieces);
    printInfo("Precomputing Pieces and choosing seeders for Pieces");

    /* Thread Pool*/

     vector<thread> threads;

    // Create two worker threads
    for (size_t i = 0; i < 2; ++i) {
        threads.emplace_back(worker);
    }

    // Push tasks into the queue
    for (size_t i = 0; i < peersWithFile.size(); ++i) {
        fileInformation* fiptr = new fileInformation();
        vector<string> temp = splitFromDelimiter(peersWithFile[i], ':');
        // cout << i << " User: " << temp[0] << " | " << " Port: " << temp[1] << endl; //test

        fiptr->fName = inpt[2]; 
        fiptr->usernm = temp[0];
        fiptr->port = stoi(temp[1]);
        fiptr->fSize = fileSizeStr; 
        fiptr->pieces = pieces;

        {
            lock_guard<mutex> lock(queueMutex);
            taskQueue.push(fiptr);
        }

        cv.notify_one(); // Notify one waiting thread
    }

    // Signal that all tasks have been added
    {
        lock_guard<mutex> lock(queueMutex);
        done = true;
    }
    cv.notify_all(); // Wake up all threads to finish

    // Join the threads
    for (auto& th : threads) {
        th.join();
    }
    
    /* Thread Pool Ends */


/*  COMMENTED *********

    // vector<thread> th, th2;
    vs temp;
    for(size_t i=0; i<peersWithFile.size(); i++){
        fileInformation* fiptr = new fileInformation();
        temp = splitFromDelimiter(peersWithFile[i],':');
        cout<< i <<" usr: " << temp[0] << " | " << " Port: " << temp[1]<<endl;
        fiptr->fName = inpt[2];
        fiptr->usernm = temp[0];
        fiptr->port =   stoi(temp[1]);
        fiptr->fSize = fileSizeStr;
        fiptr->pieces = pieces;
        getPieceInfoFromPeers(fiptr);
        // th.push_back(thread(getPieceInfoFromPeers, fiptr));
       
    }

    //  for(auto it=th.begin(); it!=th.end();it++){
    //     if(it->joinable()) it->join();
    // }
***** COMMENTED */    
    printInfo("gathered information needed for file downloading...");
    
//checking if each chunk is available or not.
    for(size_t i=0; i<curDownFilePieces.size(); i++){
        if(curDownFilePieces[i].size() == 0){
            printerror("Error: Could not find all the parts of the file available to download.");
            return -1;
        }
    }
    // th.clear();

    struct stat info;
    if (stat(inpt[3].c_str(), &info) != 0) { // Check if directory exists
        mkdir(inpt[3].c_str(), 0755); // Create the directory with permissions
    }

    string destPath = inpt[3] + "/" + inpt[2];
    FILE* fd = fopen(&destPath[0], "r+");
	if(fd != 0){
		printInfo("The file already exists.") ;
        fclose(fd);
        downloadedFiles[inpt[1]][inpt[2]] = true;
        return 1;
	} else printInfo("The file already does not exists. creating it") ;

    
    createFileForWrite(destPath, stoll(fileSizeStr));

    fileChunkInfo[inpt[2]].resize(pieces,0);
    vector<int> tmp(pieces, 0);
    isCorruptedFile = false;
    fileChunkInfo[inpt[2]] = tmp;

    string peerToGetFilepath;
    srand((unsigned) time(0)); // intialise to get a random num
    long long pieceReceived = 0;

    while(pieceReceived < pieces){
        printInfo("connecting to get Piece count: " + to_string(pieceReceived));
        
        int randomPiece;
        while(true){
            randomPiece = rand()%pieces;
            // printInfo("selected random piece = " + to_string(randomPiece));
            if(fileChunkInfo[inpt[2]][randomPiece] == 0) break; //download undownloaded one
        }
        long long peersWithThisPiece = curDownFilePieces[randomPiece].size();
        string randompeer = curDownFilePieces[randomPiece][rand()%peersWithThisPiece];
        
        reqstdPieceDetails* reqMeta = new reqstdPieceDetails();
        reqMeta->filename = inpt[2];
        reqMeta->serverPeerIP = randompeer;
        reqMeta->chunkNum = randomPiece;
        reqMeta->destination = inpt[3] + "/" + inpt[2];
        reqMeta->fileSize = fileSizeStr;

        printInfo("Initiating thread for Piece number "+ to_string(reqMeta->chunkNum));
        fileChunkInfo[inpt[2]][randomPiece] = 1;
        downloadedFiles[inpt[1]][inpt[2]] = false;
        // th2.push_back(thread(getfilePiece, reqMeta));
        if(getfilePiece(reqMeta) != -1);
            pieceReceived++;
        
        peerToGetFilepath = randompeer;
    }    
    // for(auto it=th2.begin(); it!=th2.end();it++){
    //     if(it->joinable()) it->join();
    // } 

    if(isCorruptedFile){
        //report failure to tracker
        printColor('R'); 
        printInfo("Error: Downloaded completed but file maybe corrupted.");
        resetColor();
        downloadedFiles[inpt[1]].erase(inpt[2]);
    }
    else{
        //report success to tracker
        printColor('G');    
        printInfo("Download completed Successfully.");
        resetColor();
        downloadedFiles[inpt[1]][inpt[2]] =  true;
        fileInformation fileInfo;
        fileInfo.fName = inpt[2];
        fileInfo.fPath = string(inpt[3] + "/" + inpt[2]).c_str();
        fileInfo.filePath = inpt[3] + "/" + inpt[2];
        fileInfo.fSize = fileSizeStr;
        // fileInfo.fullHash = filehash;
        fileInfo.pieceswiseHash = sha1Pieces;
        fileInfo.clientSockt = sock;
        fileInfo.port = myPort;
        fileInfo.Ip = myIp;
        fileInfo.pieces = pieces;
        uploadedfileToFInfo[inpt[2]] = fileInfo;
        
        return 1;
    }

    // vs serverAddress = splitFromDelimiter(peerToGetFilepath, ':');
    // peerToPeerConnect(&serverAddress[0][0], stoi(serverAddress[1]), "get_file_path$" + inpt[2]);
    return -1;
}



/***********************************************************************************************

                            LOGIC FOR SEEDER STAARTS HERE

***********************************************************************************************/



// request processing of peer/cleint
void runCommands(int cSock){
    printInfo("\n Client Socket: " + to_string(cSock) + " ready to run comands"); //test

    char reply[COMMAND_BUFFER_SIZE]; 
    bzero(reply, COMMAND_BUFFER_SIZE); // Clear the reply buffer

    if(recv(cSock , reply, COMMAND_BUFFER_SIZE, 0) <=0){  // Receive request from client
        printInfo("Seeder Failed to get/read response from  requesting client, response: " + string(reply));
        close(cSock);
    }
    else {
       
        printInfo("client request for seeder: " + string(reply));
        vs inpt = splitFromDelimiter(string(reply), '$');
        printInfo("requested cmd: " + inpt[0]); // test

        if(inpt[0] == "send_pieces_Info"){   //cmd receieved to get pieces info 
            printInfo("sending pieces Info...");
            string filename = inpt[1];
            vector<int> chnkvec = uploadedfileToFInfo[filename].availabePieces;
            string tmp = "";
            for(auto i: chnkvec) tmp += to_string(i); 
            char* reply = &tmp[0];
            send(cSock, reply, COMMAND_BUFFER_SIZE, 0);
            printInfo("sent pieces Info: " + string(reply));
        }
        else if(inpt[0] == "getDataPiece"){
            //inpt Format {getDataPiece, filename, to_string(pieceNum), destination}
            printInfo("sending piece...");

            int chunkNum = -1;
            if(uploadedfileToFInfo.find(inpt[1]) != uploadedfileToFInfo.end()) {
                string filepath = (uploadedfileToFInfo[inpt[1]].filePath);
                chunkNum = stoi(inpt[2]);
                printInfo("filepath: "+ filepath);
                printInfo("sending Piece No: " + to_string(chunkNum) + " from Ip Addr =  " + string(myIP) + ":" + to_string(myPort));
                transferDataPiece(&filepath[0], chunkNum, cSock);
            }
            else {
                printerror("Error: Failed to send Piece No: " + to_string(chunkNum) + " from Ip Addr =  " + string(myIP) + ":" + to_string(myPort));
                char buffer[COMMAND_BUFFER_SIZE] = {0};
                string errInfo = "Error: Failed to send Piece No: " + to_string(chunkNum) + " from Ip Addr =  " + string(myIP) + ":" + to_string(myPort);
                strcpy(buffer, errInfo.c_str());
                int rc = 0;
                if ((rc = send(cSock, buffer, COMMAND_BUFFER_SIZE, 0)) == -1) {
                    printerror("Error: Failed while seeder error info for transfer file.");
                    exit(EXIT_FAILURE);
                }
            }
        }
        else if(inpt[0] == "get_file_path"){
            string filepath = (uploadedfileToFInfo[inpt[1]].filePath); 
            bzero(reply, COMMAND_BUFFER_SIZE); // Clearing the reply buffer
            strcpy(reply, filepath.c_str());
            printInfo("request command received from peer client: " +  string(reply));
            send(cSock, reply, COMMAND_BUFFER_SIZE,0);
        }
        else {
            printInfo("request command received is Invalid : " +  string(reply));
            bzero(reply, COMMAND_BUFFER_SIZE); // Clearing the reply buffer
            strcpy(reply, "Error: Send Valid Command");
            send(cSock, reply, COMMAND_BUFFER_SIZE,0);
        }


    }

}


void clientSeederCommandHelper(int cSock) {
    //color
    printColor('Y');
    printf("Seeder Opened New thread for client: %d is opened\n", cSock);
    printColor('G');
    printf("Client is now connected to Seeder\n");
    resetColor();
    //reset color

    runCommands(cSock);
    close(cSock); // Closeing the socket connection for thread
    
    //color
    printColor('B');
    printf("Client: %d is now Disconnected from Seeder\n", cSock);
    resetColor();
    //reset color
}

void startSeederForConnection(int socket, sockaddr_in server_ipPort ) {
    vector<thread> threadVec;
    int addrlen = sizeof(server_ipPort);
    while(true){
        int clientSocket = accept(socket, (SockAdd *)&server_ipPort, (socklen_t *)&addrlen);
        if(clientSocket  < 0){
            printerror("Error while accepting the connection request at seeder");
            continue;
        }
        printColor('G');
        printInfo("Connection Accepted Successfully at seeder");
        resetColor();
        threadVec.push_back(thread(clientSeederCommandHelper, clientSocket));
    }
    // for(auto it=threadVec.begin(); it!=threadVec.end();it++){
    //     if(it->joinable()) it->join();
    // }
    for (auto& thread : threadVec) {
        if (thread.joinable()) {
            thread.join();
        }
    }
    close(socket);
}

void* actAsSeeder(void* arg){ 
    int seeder_socket; 
    struct sockaddr_in address; 
    int addrlen = sizeof(address); 
    int ArgOption = 1; 

    printInfo("\n Making Seeder Up at Port: " + to_string(myPort) + " and it will keep running as server");
    if ((seeder_socket = socket(AF_INET, SOCK_STREAM, 0)) == 0) { 
        printerror("socket creation failed for seeder"); 
        exit(EXIT_FAILURE); 
    } 
    printInfo(" Client successfully created a Seeder server socket.");

    if (setsockopt(seeder_socket, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &ArgOption, sizeof(ArgOption))) { 
        printerror("setsockopt command failed"); 
        exit(EXIT_FAILURE); 
    } 
    address.sin_family = AF_INET; 
    address.sin_port = htons(myPort); 

    if(inet_pton(AF_INET, &myIP[0], &address.sin_addr)<=0)  { 
        printerror("\nThis is not a valid address or  address may not be supported"); 
        return NULL; 
    } 
       
    if (bind(seeder_socket, (SockAdd *)&address,  sizeof(address))<0) { 
        printerror("bind command failed"); 
        exit(EXIT_FAILURE); 
    } 
    printInfo("Client successfully did Binding for Seeder server.");

    if(listen(seeder_socket, 3) < 0) { 
        printerror("listen command failed"); 
        exit(EXIT_FAILURE); 
    } 
    printInfo("Seeder Listening....");

    startSeederForConnection(seeder_socket, address);
    printf("EXITING Seeder.\n");
    return NULL;
}
/***********************************************************************************************

                            LOGIC FOR SEEDER ENDS HERE

***********************************************************************************************/

void handleUploadFile(vs inpt, int sock, string myIp, int myPort) {
    if(inpt[0] != "Error:") {
        
        bool errorFlag = false;
        const char* filepath = inpt[1].c_str();
        string clientAddress = myIp + ":" + to_string(myPort);
        string filehash = getFileSha1(filepath);
        if(filehash == "") {
            errorFlag = true;
        }
        else {
            string filesize =  to_string(getFileSize(filepath));
            if(filesize == "-1") {
                errorFlag = true;
            }
            else {
                string fileName = splitFromDelimiter(inpt[1], '/').back();
                int pieces = ceil(stoi(filesize)/(float)PIECE_SIZE); //524288.0);

                // string piecewiseHash = "aab"; // getHash(filepath);
                // if(piecewiseHash == "$") return 0;

                fileInformation fileInfo;
                fileInfo.fName = fileName;
                fileInfo.fPath = filepath;
                fileInfo.filePath = string(filepath);
                fileInfo.fSize = filesize;
                fileInfo.fullHash = filehash;
                fileInfo.clientSockt = sock;
                fileInfo.port = myPort;
                fileInfo.Ip = myIp;
                fileInfo.pieces = pieces;

                string fileMetaData = string(filepath) + "$";
                fileMetaData += clientAddress + "$";
                fileMetaData += filesize + "$";
                fileMetaData += filehash + "$";
                fileMetaData += to_string(pieces);
                // cout<< " total data pieces: " << pieces <<endl; // test
                printColor('c');
                printInfo(".......");
                resetColor();
                for(int i = 0; i < pieces; i++) {
                    string piecewiseHash = getPieceSha1(filepath, filesize, i);

                    fileInfo.pieceswiseHash.push_back(piecewiseHash);
                    fileInfo.availabePieces.push_back(i);
                    fileMetaData += "$" + piecewiseHash;
                }

                // printInfoSl("sending file details for upload: ");
                // printInfo(fileMetaData); //test

                const size_t METADATA_SIZE = strlen(&fileMetaData[0]);
    

                char trackerReply[METADATA_SIZE] = {0}; 
                strcpy(trackerReply, fileMetaData.c_str());
                
                // if(send(sock , &fileMetaData[0] , strlen(&fileMetaData[0]) , 0 ) == -1){
                if(send(sock , trackerReply , METADATA_SIZE , MSG_NOSIGNAL ) == -1){
                // if(send(sock , trackerReply , COMMAND_BUFFER_SIZE , MSG_NOSIGNAL ) == -1){
                    printf("Error: while uploading,  %s\n",strerror(errno));
                }
                else {
                    // char trackerReply[10240] = {0}; 
                    // read(sock , trackerReply, 10240); 
                    char trackerReply[COMMAND_BUFFER_SIZE] = {0}; 
                    recv(sock , trackerReply, COMMAND_BUFFER_SIZE, 0); 
                    printInfoSl("Status: 200, Response recieved : ");
                    printInfo( string(trackerReply));
                    uploadedfileToFInfo[fileName] = fileInfo;

                     //test
        string fpt = string(uploadedfileToFInfo[fileName].fPath);
        string fptt = uploadedfileToFInfo[fileName].filePath;
        string fpttt = uploadedfileToFInfo[fileName].fSize;
        // cout<<"FilePath from uploadedfileToFInfo: " << fpt <<  " | " << fptt <<   " | " << fpttt <<endl; //test
                }
            }
        }
        if(errorFlag) {
            if(send(sock, "error" , strlen("error") , MSG_NOSIGNAL ) == -1){
                printf("Error: %s\n",strerror(errno));
            }
            else {
                char trackerReply[COMMAND_BUFFER_SIZE] = {0}; 
                recv(sock , trackerReply, COMMAND_BUFFER_SIZE, 0); 
                printInfoSl("Status: 200, Response recieved : ");
                printInfo( string(trackerReply));
            }
        }
    
    }
}

void handleDownloadFile(vs inpt, int sock, string myIp, int myPort) {
    char trackerReply[COMMAND_BUFFER_SIZE] = {0}; 
    
    bzero(trackerReply, COMMAND_BUFFER_SIZE); 
    strcpy(trackerReply, "requesting peers");
    // cout<<"requesting peers"<<endl; //test

    // if(send(sock , &fileMetaData[0] , strlen(&fileMetaData[0]) , 0 ) == -1){
    if(send(sock , trackerReply, COMMAND_BUFFER_SIZE, MSG_NOSIGNAL ) == -1) {
        printerrorSl("Error: "), printerror(strerror(errno));
    } else {
        
        bzero(trackerReply, COMMAND_BUFFER_SIZE);
        read(sock , trackerReply, COMMAND_BUFFER_SIZE); 
        printInfoSl("Status: 200, Response recieved : ");
        printInfo( string(trackerReply));
        vs peersWithFile = splitFromDelimiter(trackerReply, '$');
        string fileSizeStr = peersWithFile.back();
        peersWithFile.pop_back();
        fileToPeerInfo[inpt[2]] = peersWithFile;

        bzero(trackerReply, COMMAND_BUFFER_SIZE);
        strcpy(trackerReply, "requesting pieces");
        // cout<<"requesting pieces"<<endl; //test
        if(send(sock , trackerReply, COMMAND_BUFFER_SIZE, MSG_NOSIGNAL ) == -1) {
            printerrorSl("Error: "), printerror(strerror(errno));
        } else {
            
            bzero(trackerReply, COMMAND_BUFFER_SIZE);
            read(sock , trackerReply, COMMAND_BUFFER_SIZE); 
            printInfoSl("Status: 200, Response recieved : ");
            printInfo( string(trackerReply));
            vs sha1Pieces = splitFromDelimiter(string(trackerReply), '$');
            fileToPiecesInfo[inpt[2]] = sha1Pieces;
            
            int dwnlstatus = preComputeForDownload( inpt, sock, myIp, myPort, peersWithFile, sha1Pieces, fileSizeStr );
            
            //updating download status
                bzero(trackerReply, COMMAND_BUFFER_SIZE); 
                if(dwnlstatus == -1)
                    strcpy(trackerReply, "download_status 0");
                else
                    strcpy(trackerReply, "download_status 1");

                if(send(sock , trackerReply, COMMAND_BUFFER_SIZE, MSG_NOSIGNAL ) == -1) {
                    printerrorSl("Error: "), printerror(strerror(errno));
                } else { 
                    printInfo("Success: sending msg to update downloading status");
                }

        }
    }
}

void handleShowDownloadedFile(vs inpt, int sock, string myIp, int myPort) { 
    //[D] [grp_id] filename

    //[C] [grp_id] filename
    
    if(downloadedFiles.size() <= 0) {
        printInfo("No Downloads to show");
    }
    else {
        for(auto j : downloadedFiles) {
            for(auto i : downloadedFiles[j.first]) { 
            if(i.second)
                printInfo("[C] " + j.first + " " + i.first );
            else
                printInfo("[D] " + j.first + " " + i.first );
            }
        }
    }
}


int main(int argc, char *argv[]) {

    if(argc != 3) {
        printerrorSl("Usage: "), printerrorSl(argv[0]), printerror(" <ip_address>:<port_number> <tracker_info.txt");
        exit(EXIT_FAILURE);
    }

    // Split the ip-port string
    vs nodeAddress = splitFromDelimiter(argv[1], ':');
    if (nodeAddress.size() != 2) {
        printerror("Invalid input ip/port format. Expected <ip_address:port_number>.");
        exit(EXIT_FAILURE);
    }
    myIP = nodeAddress[0];
    myPort = stoi(nodeAddress[1]);


    int sock = 0;
    string trackerIpAddress;
    int trackerPort;

    vs trackerData;
    readTrackerInfoFile(argv[2], trackerData);  
    if (trackerData.size() < 2) {
        printerror("Error: Expected at least 2 lines in the tracker info file.");
        exit(EXIT_FAILURE);
    }
    trackerIpAddress = trackerData[0];
    trackerPort = stoi(trackerData[1]);

   // Create socket
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        printerror("Socket creation error for client");
        exit(EXIT_FAILURE);
    }

    pthread_t serverThread;
    if(pthread_create(&serverThread, NULL, actAsSeeder, NULL) == -1){
        printerror("pthread for making client a seeder failed. "); 
        exit(EXIT_FAILURE); 
    }

    struct sockaddr_in server_ipPort;
    server_ipPort.sin_family = AF_INET;
    server_ipPort.sin_port = htons(trackerPort);

    // Converting the IPv4 and IPv6 addresses from text to binary number format
    if (inet_pton(AF_INET, trackerIpAddress.c_str(), &server_ipPort.sin_addr) <= 0) {
        printerror("Not a Valid address or Address may not be supported");
        exit(EXIT_FAILURE);
    }
    
    //retry logic
    int retryCount = 0;
    const int maxRetries = 3;
    while (connect(sock, (struct sockaddr *)&server_ipPort, sizeof(server_ipPort)) < 0) {
        printerrorSl("Establishing Connection Failed. Retrying... Retry: "), printerror(to_string(++retryCount));
        if (retryCount >= maxRetries) {
            printColor('c');
            printerror("Failed to connect after retrying, Establishing Connection Failed!! ");
            resetColor();
            exit(EXIT_FAILURE);
        }
        sleep(2); // Wait for 2 second between each retry
    }

    char serverResponse[COMMAND_BUFFER_SIZE] = {0};
    string testmessage = "handshake";
    send(sock, testmessage.c_str(), testmessage.length(), 0);
    printInfo("Handshake sent from client");
    
    // // Read server response
    bzero(serverResponse, COMMAND_BUFFER_SIZE);
    int statusRead = read(sock, serverResponse, COMMAND_BUFFER_SIZE);
    if(checkRead(statusRead)) {
        printerror("Failed on handshaking");
        exit(EXIT_FAILURE);
    }

    string testing = string(serverResponse) ;
    if (testing != "handshake") {
        printerror("Failed to connect, Handshaking failed, Establishing Connection Failed!! with respone: ");
        printerror(serverResponse);
        exit(EXIT_FAILURE);
    }
    else
        printInfo("Handshake received from server : Connection OK ");

    loggedIn=false;
    printColor('g');
    printInfo("Connection succeful start giving commands");
    printColor('x');
    printInfo("-------------------------------------------\n");
    resetColor();

    while(5) {
        // Ip message for server/tracker
        printInfoSl("-->> ");
        string requst;
        getline(cin,requst);
        requst = trimLeadingTrailingSpaces(requst); 
        vs inptStr = splitFromDelimiter(requst,' ');

        if(inptStr[0] == "login" && loggedIn){
            printInfo("You already have one active logged in session, please continue or logout first !!");
            continue;
        }
        if(!isValidInput(inptStr[0])) {
            printInfo("Please enter valid command!!");
                continue;
        }

        if(inptStr[0] != "login" && inptStr[0] != "create_user" && inptStr[0] !="quit" &&!loggedIn){
            printInfo("Please login or create an account first !!");
                continue;
        }
        
        // cout << " sending req: " << requst << endl; //test

        if(send(sock, requst.c_str(), requst.length(), 0) == -1) {
            printerror("Failed to send the requst to the server");
            break;
        }
        // else cout << "Requst has been sent to the server " << requst << endl;

        // Read server response
        bzero(serverResponse, COMMAND_BUFFER_SIZE);
        statusRead = read(sock, serverResponse, COMMAND_BUFFER_SIZE);
        // recv(sock, serverResponse,COMMAND_BUFFER_SIZE,0);
        if(checkRead(statusRead)) break;

        if(inptStr[0]=="quit"){ 
            loggedIn = false;
            printColor('b');
            printInfo("Logging Out... \nDisconnecting...");
            resetColor();
            break;
        }


        printInfoSl("Status: 200, Response recieved : ");
        printInfo(serverResponse);

        if(inptStr[0] == "upload_file"){
            if(string(serverResponse) == "Started Uploading ..."){
                handleUploadFile(inptStr, sock, myIP, myPort);
            }
        } else if(inptStr[0] == "download_file") {
            if(string(serverResponse) == "Started Downloading ..."){
                handleDownloadFile(inptStr, sock, myIP, myPort);
            }
        } else if(inptStr[0] == "show_downloads") {
            if(string(serverResponse) == "showing_downloads"){
                handleShowDownloadedFile(inptStr, sock, myIP, myPort);
            }
        }

        clientCommandHelper(inptStr[0], serverResponse, sock, myPort, loggedIn);
        // cout<<"end of loop "<<endl;
    }
    // Closing the socket
    close(sock);
    printColor('Y');
    printInfo("Closing Client...");
    resetColor();
    return 0;
}