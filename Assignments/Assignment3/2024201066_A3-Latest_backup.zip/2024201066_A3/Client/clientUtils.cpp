#include "header_files.h"

 void printInfo(string info) {
    cout << info <<endl;
 }
  
 void printInfoSl(string info) {
    cout << info ;
}

void printerror(string er){
    cerr << er << endl;
}

void printerrorSl(string er){
    cerr << er;
}

int isValidInput(string inp0) {
    if(inp0 == "login") return 1;
    else if(inp0 == "logout") return 1;
    else if(inp0 == "create_user") return 1;
    else if(inp0 == "create_group") return 1;
    else if(inp0 == "join_group") return  1;
    else if(inp0 == "leave_group") return 1;
     else if(inp0 == "list_groups") return 1;
    else if(inp0 == "list_requests") return 1;
    else if(inp0 == "accept_request") return 1;
    else if(inp0 == "upload_file") return 1;
    else if(inp0 == "download_file") return 1;
    else if(inp0 == "show_downloads") return 1;
    else if(inp0 == "list_files") return 1;
    else if(inp0 == "stop_share") return 1;
    else if(inp0 == "quit") return 1;
    else return 0;
}

int checkRead(int rstatus) {
      if (rstatus < 0) {
        printerror("Error: while Reading Response");
        return 1;
      }
      else if(rstatus == 0) {
        printerror("Connection Broken, Try Reconnecting");
        return 1;
      }
      else return 0;
}

void readTrackerInfoFile(const char* filename, vector<string>& data) {
    // Opening the file using the open system call
    int fd = open(filename, O_RDONLY);
    if (fd == -1) {
        printerrorSl("Error: Failed to open file: "), printerror(filename );
        exit(EXIT_FAILURE);
    }

    FILE* file = fdopen(fd, "r");
    if (!file) {
        printerror("Error: Failed to convert the file descriptor to FILE* type");
        close(fd);
        exit(EXIT_FAILURE);
    }

    char buffer[BUFFER_SIZE];

    // Reading all lines into the buffer
    while (fgets(buffer, BUFFER_SIZE, file) != NULL) {
        // Remove newline character if present
        buffer[strcspn(buffer, "\n")] = '\0';
        data.push_back(buffer); // Store each line in the vector
    }
    // Checking here for errors in reading
    if (ferror(file)) {
        printerrorSl("Error: while reading ip port details from file: "), printerror(filename);
    }

    // Closeing the file desc
    fclose(file);
}

string trimLeadingTrailingSpaces(string& ipStr) {
    size_t startExcludingTabs = ipStr.find_first_not_of(" \t");
    size_t endExcludingTabs = ipStr.find_last_not_of(" \t");

    // If the string is having only spaces, then returning an empty string
    if (startExcludingTabs == string::npos) {
        return "";
    }

    // Returning the final trimmed substring
    return ipStr.substr(startExcludingTabs, endExcludingTabs - startExcludingTabs + 1);
}

long long getFileSize(const char* path){
    string inputPath = string(path);
    if (inputPath.compare(0, 2, "./") == 0) {
        inputPath = inputPath.substr(2); // Remove "./"
    }
    else if (inputPath.compare(0, 1, "/") == 0) {
        inputPath = inputPath.substr(1); // Remove "/"
    }
    path = inputPath.c_str();
    
    FILE *fd = fopen(path, "rb"); 

    long size=-1;
    if(fd){
        fseek (fd, 0, SEEK_END);
        size = ftell(fd)+1;
        fclose(fd);
    }
    else{
        printf("unable to find file\n");
        return -1;
    }
    return size;
}
/*
string getFileSha1(const char* path) {
    string inputPath = string(path);
    if (inputPath.compare(0, 2, "./") == 0) {
        inputPath = inputPath.substr(2); // Remove "./"
    }
    else if (inputPath.compare(0, 1, "/") == 0) {
        inputPath = inputPath.substr(1); // Remove "/"
    }
    path = inputPath.c_str();

    ifstream input (path);
    if (!input.is_open()) {
        printerror("Error: Unable to open file: " + string(path));
        return "";
    }

    ostringstream strBuf; 
    strBuf << input.rdbuf();

    if (input.bad()) {
        printerror("Error: Problem has occured while reading from the file.");
        return "";
    }

    string fileContents =  strBuf.str();
    if (fileContents.empty()) {
        printerror("Warning: File is empty or not having any data.");
    }

    string sha1;
    unsigned char sha1buff[SHA256_DIGEST_LENGTH];
    if(!SHA256(reinterpret_cast<const unsigned char *>(&fileContents[0]), fileContents.length(), sha1buff)){
        printerror("Error in calculating sha1");
    }
    else{
        for(int i=0; i<SHA256_DIGEST_LENGTH; i++){
            char chbuffer[3];
            sprintf(chbuffer, "%02x", sha1buff[i]&0xff);
            sha1 += string(chbuffer);
        }
    }
    cout << "Sha-1 --> " << sha1 << endl;
    return sha1;
}
*/
string getContentSha1(const char* content, size_t bytesRead) {
    char buffer[PIECE_SIZE] ;
    strcpy(buffer, content);
    unsigned char sha1buff[SHA_DIGEST_LENGTH];
    if (!SHA1(reinterpret_cast<const unsigned char*>(buffer), bytesRead, sha1buff)) {
        printerror("Error: Failed while calculating SHA-1");
        return "";
    }

    // Convert SHA-1 to hexadecimal string
    string sha1;
    for (int i = 0; i < SHA_DIGEST_LENGTH; i++) {
        char chbuffer[3];
        sprintf(chbuffer, "%02x", sha1buff[i]);
        sha1 += string(chbuffer);
    }

    // cout << "Content Piece SHA-1 --> " << sha1 << endl; //test

    return sha1;
}

string getFileSha1(const char* path) {
   printInfo("Begining: calculation for Sha1 for Complete File");
   long fsize= getFileSize(path);
   if(fsize == -1) return "";
   int pieces = ceil((fsize)/(float)PIECE_SIZE); //524288.0);
    string piecewiseHash = "";
    for(int i = 0; i < pieces; i++) {
        piecewiseHash += getPieceSha1(path, to_string(fsize), i);

    string sha1;
    unsigned char sha1buff[SHA256_DIGEST_LENGTH];
    if(!SHA256(reinterpret_cast<const unsigned char *>(&piecewiseHash[0]), piecewiseHash.length(), sha1buff)){
        printerror("Error: Failed while calculating sha1 for Complete File");
    }
    else{
        for(int i=0; i<SHA256_DIGEST_LENGTH; i++){
            char chbuffer[3];
            sprintf(chbuffer, "%02x", sha1buff[i]&0xff);
            sha1 += string(chbuffer);
        }
    }
    // cout << "Sha-1 --> " << sha1 << endl; //test
        return sha1;
    }
}

string getPieceSha1(const char* path, string fSize, int chunkNo) {
    string inputPath = string(path);
    long fileSize = stol(fSize);

    // if (inputPath.compare(0, 2, "./") == 0) {
    //     inputPath = inputPath.substr(2); // Remove "./"
    // }
    // else if (inputPath.compare(0, 1, "/") == 0) {
    //     inputPath = inputPath.substr(1); // Remove "/"
    // }
    // path = inputPath.c_str();
    
    // Open the file
    int startOffset = chunkNo*PIECE_SIZE;
    int fd = open(path, O_RDONLY);
    if (fd == -1) {
        printerror("Error: Unable to open the file: " + string(path));
        return "";
    }

    // Seek to the specified offset
    if (lseek(fd, startOffset, SEEK_SET) == -1) {
        printerror("Error: Unable to seek to offset in file.");
        close(fd);
        return "";
    }

    // Read up to 512 Kbytes
    char buffer[PIECE_SIZE];
    ssize_t bytesRead = read(fd, buffer, sizeof(buffer));
    if (bytesRead < 0) {
        printerror("Error: Problem has occurred while reading from the file.");
        close(fd);
        return "";
    }

    // Check if file is empty
    if (bytesRead == 0) {
        printerror("Warning: File is empty or not having any data.");
    }

    // Calculate SHA-1
    unsigned char sha1buff[SHA_DIGEST_LENGTH];
    if (!SHA1(reinterpret_cast<const unsigned char*>(buffer), bytesRead, sha1buff)) {
        printerror("Error: failed while calculating SHA-1");
        close(fd);
        return "";
    }

    // Convert SHA-1 to hexadecimal string
    string sha1;
    for (int i = 0; i < SHA_DIGEST_LENGTH; i++) {
        char chbuffer[3];
        sprintf(chbuffer, "%02x", sha1buff[i]);
        sha1 += string(chbuffer);
    }

    // cout << "Piece SHA-1 --> " << sha1 << endl; //test

    // Close the file descriptor
    close(fd);
    return sha1;
}

vector<string> splitFromDelimiter(const string& ipStr, char delimiter) {
    vector<string> result;
    size_t start = 0;  // Starting index of the current substring

    // Looping through the entire string
    for (size_t end = 0; end < ipStr.length(); ++end) {
        // When the delimiter is found, extract the substring
        if (ipStr[end] == delimiter) {
            result.push_back(ipStr.substr(start, end - start)); // Extracting from delimitter and add to result
            start = end + 1; // Move the start index to the next character after the delimiter
        }
    }

    // Adding the last substring (or the only one if there were no delimiters)
    result.push_back(ipStr.substr(start));

    return result;  
}


void printColor(char colorInitial) {
    switch (colorInitial) {
        case 'G': // Green
            printf("%s", "\033[1m\033[32m");
            break;
        case 'B': // Blue
            printf("%s", "\033[1m\033[34m");
            break;
        case 'C': // Cyan
            printf("%s", "\033[1m\033[36m");
            break;
        case 'x' : // white
            printf("%s", "\033[97m");
            break;
        case 'Y': // Yellow
            printf("%s", "\033[1m\033[33m");
            break;
         // Light Colors
        case 'g': // Light Green
            printf("%s", "\033[1m\033[92m");
            break;
        case 'b': // Light Blue
            printf("%s", "\033[1m\033[94m");
            break;
        case 'c': // Light Cyan
            printf("%s", "\033[1m\033[96m");
            break;
        // Background Colors
        case 'R': //Red             // Background Red
            printf("\033[91m");  // printf("%s", "\033[41m");
            break;
        case 'M': // Background Magenta
            printf("%s", "\033[45m");
            break;
        case 'W': // Background White
            printf("%s", "\033[47m");
            break;
        // Light Background Colors
        case 'k': // Light Background Black (Gray)
            printf("%s", "\033[100m");
            break;
        case 'r': // Light Background Red
            printf("%s", "\033[101m");
            break;
        case 'm': // Light Background Magenta
            printf("%s", "\033[105m");
            break;
        case 'w': // Light Background White
            printf("%s", "\033[107m");
            break;
        default:
            // printf("Invalid color initial.\n");
            return;
    }
}

void resetColor() {
    printf("%s", "\033[0m");
}

void clearLine() {
    printf("\033[2K"); // Clear entire line
}
