#include "header_files.h"

void clientCommandHelper(string input0, char* serverResp, int sock, int myPort, bool &loggedIn) {
    string responseString = string(serverResp);
        if(input0 =="login" && responseString == "Successfully logged in!!") {
                loggedIn=true;
                bzero(serverResp,COMMAND_BUFFER_SIZE);
                strcpy(serverResp,&to_string(myPort)[0]);
                printInfoSl("Client : "),printInfo(serverResp);
                send(sock, serverResp, sizeof(serverResp), 0);
                printInfo("************* Logged In Using Port " + to_string(myPort) +" !! *************\n");
        } else if(input0 =="logout" && responseString == "Success" ){
                loggedIn=false;     
                printInfo("************* Logged Out Successfully*************\n");
        } else if(input0 =="list_groups" && responseString == "Success"){
                bzero(serverResp,COMMAND_BUFFER_SIZE);
                recv(sock, serverResp, COMMAND_BUFFER_SIZE,0);
                printInfo("************* Below are Group Details **************");
                printInfo(serverResp);
        } else if(input0=="list_requests"){
            if(responseString=="Success"){
                bzero(serverResp,COMMAND_BUFFER_SIZE);
                recv(sock, serverResp, COMMAND_BUFFER_SIZE,0);
                printInfo("************* Below are Pending Requests ***************");
                printInfoSl("Tracker : "),printInfo( serverResp);
            }
        } else if(input0=="list_files"){
            if(responseString=="Success"){
                bzero(serverResp,COMMAND_BUFFER_SIZE);
                recv(sock, serverResp, COMMAND_BUFFER_SIZE,0);
                printInfo("************* Below are Available Files in Group **************");
                printInfoSl("Tracker : "),printInfo(serverResp);
            }
        }
        //  else if(responseString == "closing connection") {
        //         cout << "************* Disconnected From Tracker ************** \n";
        // }
}
