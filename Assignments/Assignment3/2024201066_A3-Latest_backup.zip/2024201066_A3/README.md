   # Description: Peer-to-Peer File Sharing System

The Peer-to-Peer File Sharing System enables users to efficiently share files and resources over a decentralized network. It consists of a Tracker that manages user registrations and group memberships, while Clients can create accounts, join or leave groups, and share files seamlessly with other users. This system is designed to facilitate easy communication and collaboration among users, making it ideal for file distribution and group sharing in a secure environment.
  
**Assumptions:** 

1. Download won't allow downloading file from self as we already have the file.
2. Client and Tracker data preserve across session.
3. Ownership changes randomly to another user of same group, if all user leaves the group then group is deleted.
   
  ## How to execute
   - Client
      ```
      cd myClient
      make
   
      ```
   - Go to parent directory
      ``` 
      cd ..
      ````
   - Tracker
      ```
      cd myTracker
      make
      cd ..
      ```

   ## Usage/Components
   ### Tracker

3. Run Tracker:
   Note: Max 2 trackers are implemented.

   ```
   cd tracker
   ./tracker​ <TRACKER INFO FILE> <Number of Trackers>
   example: ./tracker tracker_info.txt 1
   ```

   `<TRACKER INFO FILE>` contains the IP, Port details of all the trackers separated by line.

   ```
   Example:
   127.0.0.1
   5000
   127.0.0.1
   6000
   ```

   1. Close Tracker:

   ```
   quit
   ```

### Client:

   3.  Run Client:

      ```
      cd myClient
      ./client​ <IP>:<PORT> <TRACKER INFO FILE>
      example: ./client 127.0.0.1:8070 tracker_info.txt
      ```

      4.  Create user account:

      ```
      create_user​ <user_id> <password>
      ```

      5.  Login:

      ```
      login​ <user_id> <password>
      ```

      6.  Create Group:

      ```
      create_group​ <group_id>
      ```

      7.  Join Group:

      ```
      join_group​ <group_id>
      ```

      8.  Leave Group:

      ```
      leave_group​ <group_id>
      ```

      9.  List pending requests:

      ```
      list_requests ​<group_id>
      ```

      10. Accept Group Joining Request:

      ```
      accept_request​ <group_id> <user_id>
      ```

      11. List All Group In Network:

      ```
      list_groups
      ```

   ## Prerequisites

   - G++ compiler
      - **To install G++ :** `sudo apt-get install g++`
   - OpenSSL library

      - **To install OpenSSL library :** `sudo apt-get install openssl`
   - Developed for Linux based OS